"""Banco SQLite, migração, leituras e backup consistente."""
import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime
from pathlib import Path

import pandas as pd
import streamlit as st

from formatos import centavos, total_item

PASTA = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("MERCADO_PANDAS_DB", str(PASTA / "bd_pandas.db"))).resolve()
VERSAO = 1

TABELAS = (
    """CREATE TABLE IF NOT EXISTS produtos (
        id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL UNIQUE,
        categoria TEXT NOT NULL, valor REAL NOT NULL CHECK (valor >= 0),
        unidade TEXT NOT NULL DEFAULT 'un', custo REAL NOT NULL DEFAULT 0,
        estoque REAL NOT NULL DEFAULT 0, estoque_minimo REAL NOT NULL DEFAULT 0,
        ativo INTEGER NOT NULL DEFAULT 1, controla_estoque INTEGER NOT NULL DEFAULT 0,
        custo_conhecido INTEGER NOT NULL DEFAULT 0, revisao INTEGER NOT NULL DEFAULT 0
    )""",
    """CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT, login TEXT NOT NULL UNIQUE,
        nome TEXT NOT NULL, senha_hash TEXT NOT NULL,
        perfil TEXT NOT NULL CHECK (perfil IN ('admin', 'caixa')),
        ativo INTEGER NOT NULL DEFAULT 1
    )""",
    """CREATE TABLE IF NOT EXISTS compras (
        id INTEGER PRIMARY KEY AUTOINCREMENT, data TEXT NOT NULL,
        desconto REAL NOT NULL DEFAULT 0 CHECK (desconto >= 0),
        forma_pagamento TEXT NOT NULL DEFAULT 'Não informado',
        operador TEXT NOT NULL DEFAULT 'Não informado',
        cliente TEXT NOT NULL DEFAULT '', usuario_id INTEGER REFERENCES usuarios(id),
        cancelada_em TEXT, revisao INTEGER NOT NULL DEFAULT 0, criada_em TEXT,
        operacao TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS vendas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        produto_id INTEGER NOT NULL REFERENCES produtos(id),
        nome TEXT NOT NULL, categoria TEXT NOT NULL,
        qtde REAL NOT NULL CHECK (qtde > 0), preco REAL NOT NULL CHECK (preco >= 0),
        data TEXT NOT NULL, compra_id INTEGER REFERENCES compras(id),
        unidade TEXT NOT NULL DEFAULT 'un', custo REAL NOT NULL DEFAULT 0,
        custo_conhecido INTEGER NOT NULL DEFAULT 0, estoque_baixado REAL NOT NULL DEFAULT 0
    )""",
    """CREATE TABLE IF NOT EXISTS historico (
        id INTEGER PRIMARY KEY AUTOINCREMENT, quando TEXT NOT NULL,
        usuario_id INTEGER REFERENCES usuarios(id), operador TEXT NOT NULL,
        acao TEXT NOT NULL, referencia TEXT NOT NULL, detalhe TEXT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS importacoes (
        assinatura TEXT PRIMARY KEY, compras INTEGER NOT NULL
    )""",
)

COLUNAS = {
    "produtos": {
        "unidade": "TEXT NOT NULL DEFAULT 'un'",
        "custo": "REAL NOT NULL DEFAULT 0",
        "estoque": "REAL NOT NULL DEFAULT 0",
        "estoque_minimo": "REAL NOT NULL DEFAULT 0",
        "ativo": "INTEGER NOT NULL DEFAULT 1",
        "controla_estoque": "INTEGER NOT NULL DEFAULT 0",
        "custo_conhecido": "INTEGER NOT NULL DEFAULT 0",
        "revisao": "INTEGER NOT NULL DEFAULT 0",
    },
    "compras": {
        "cliente": "TEXT NOT NULL DEFAULT ''",
        "usuario_id": "INTEGER REFERENCES usuarios(id)",
        "cancelada_em": "TEXT",
        "revisao": "INTEGER NOT NULL DEFAULT 0",
        "criada_em": "TEXT",
        "operacao": "TEXT",
    },
    "vendas": {
        "compra_id": "INTEGER REFERENCES compras(id)",
        "unidade": "TEXT NOT NULL DEFAULT 'un'",
        "custo": "REAL NOT NULL DEFAULT 0",
        "custo_conhecido": "INTEGER NOT NULL DEFAULT 0",
        "estoque_baixado": "REAL NOT NULL DEFAULT 0",
    },
}


@contextmanager
def get_connection(*, escrita=False):
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        if escrita:
            # Reserva a escrita antes de ler o saldo ou conferir se houve edição.
            conn.execute("BEGIN IMMEDIATE")
        with conn:
            yield conn
    finally:
        conn.close()


def _migrar(conn, dados):
    adicionadas = set()
    for tabela, colunas in COLUNAS.items():
        existentes = {linha["name"] for linha in conn.execute(f"PRAGMA table_info({tabela})")}
        for nome, tipo in colunas.items():
            if nome not in existentes:
                conn.execute(f"ALTER TABLE {tabela} ADD COLUMN {nome} {tipo}")
                adicionadas.add((tabela, nome))

    if ("produtos", "unidade") in adicionadas:
        conn.executemany(
            "UPDATE produtos SET unidade=? WHERE nome=?",
            [(linha[4], linha[1]) for linha in dados["produtos"]],
        )
    if ("produtos", "custo_conhecido") in adicionadas:
        conn.execute("UPDATE produtos SET custo_conhecido=1 WHERE custo>0")
    if ("vendas", "custo_conhecido") in adicionadas:
        conn.execute("UPDATE vendas SET custo_conhecido=1 WHERE custo>0")
    for venda in conn.execute("""
        SELECT v.id,v.data FROM vendas v LEFT JOIN compras c ON c.id=v.compra_id
        WHERE c.id IS NULL
    """).fetchall():
        livre = conn.execute("SELECT 1 FROM compras WHERE id=?", (venda["id"],)).fetchone()
        cursor = conn.execute(
            "INSERT INTO compras(id,data) VALUES(?,?)",
            (None if livre else venda["id"], venda["data"]),
        )
        conn.execute("UPDATE vendas SET compra_id=? WHERE id=?", (cursor.lastrowid, venda["id"]))

    # O pacote anterior deixou 'un' nas vendas históricas, inclusive nos produtos por kg.
    if ("vendas", "unidade") in adicionadas:
        conn.execute("""UPDATE vendas SET unidade =
            COALESCE((SELECT unidade FROM produtos WHERE id=vendas.produto_id), 'un')""")
    else:
        conn.execute("""UPDATE vendas SET unidade =
            COALESCE((SELECT unidade FROM produtos WHERE id=vendas.produto_id), 'un')
            WHERE unidade='un' AND compra_id IN (
                SELECT id FROM compras WHERE forma_pagamento='Não informado'
                AND operador='Não informado'
            ) AND (SELECT COUNT(*) FROM vendas AS itens WHERE itens.compra_id=vendas.compra_id)=1""")


def init_db():
    """Prepara o banco uma vez e preserva bases existentes."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with get_connection(escrita=True) as conn:
        versao = conn.execute("PRAGMA user_version").fetchone()[0]
        if versao == VERSAO:
            return
        if versao > VERSAO:
            raise RuntimeError("Este banco foi criado por uma versão mais nova do Mercado Pandas.")

        tem_tabelas = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='produtos'"
        ).fetchone()
        dados = json.loads((PASTA / "dados_iniciais.json").read_text(encoding="utf-8"))
        for sql in TABELAS:
            conn.execute(sql)
        _migrar(conn, dados)
        if not tem_tabelas:
            conn.executemany("""INSERT INTO produtos
                (id,nome,categoria,valor,unidade,custo,custo_conhecido)
                VALUES(?,?,?,?,?,?,1)""",
                             dados["produtos"])
            conn.executemany("""INSERT INTO compras
                (id,data,desconto,forma_pagamento,operador,cliente)
                VALUES(?,?,?,?,?,?)""",
                             dados["compras"])
            conn.executemany("""INSERT INTO vendas
                (id,produto_id,nome,categoria,qtde,preco,data,compra_id,unidade,custo,custo_conhecido)
                VALUES(?,?,?,?,?,?,?,?,?,?,1)""", dados["vendas"])
        conn.execute("CREATE INDEX IF NOT EXISTS idx_compras_periodo ON compras(cancelada_em,data,id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_vendas_compra ON vendas(compra_id,id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_vendas_produto ON vendas(produto_id,compra_id)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_compra_operacao ON compras(operacao)")
        conn.execute(f"PRAGMA user_version = {VERSAO}")


def criar_backup(destino):
    """O SQLite copia também as transações que ainda estão no arquivo WAL."""
    if not DB_PATH.is_file():
        raise FileNotFoundError("Abra o Mercado Pandas uma vez para criar o banco.")
    destino = Path(destino)
    if destino.resolve() == DB_PATH:
        raise ValueError("Escolha outro arquivo para o backup.")
    destino.parent.mkdir(parents=True, exist_ok=True)
    try:
        with get_connection() as origem:
            copia = sqlite3.connect(destino)
            try:
                origem.backup(copia)
            finally:
                copia.close()
    except (sqlite3.Error, OSError):
        destino.unlink(missing_ok=True)
        raise
    return destino


def backup_manual():
    agora = datetime.now()
    return criar_backup(DB_PATH.parent / "backups" / f"bd_pandas_{agora:%Y%m%d_%H%M%S_%f}.db")


def backup_diario():
    destino = DB_PATH.parent / "backups" / f"bd_pandas_diario_{date.today():%Y%m%d}.db"
    if destino.exists():
        return
    temporario = destino.with_name(f".{destino.stem}_{os.getpid()}.tmp")
    criar_backup(temporario).replace(destino)
    # Retém as 14 cópias diárias mais recentes. As cópias manuais ficam guardadas.
    for antigo in sorted(destino.parent.glob("bd_pandas_diario_*.db"), reverse=True)[14:]:
        antigo.unlink(missing_ok=True)


@st.cache_data(ttl=20, max_entries=8, show_spinner=False)
def listar_produtos(apenas_ativos=False):
    with get_connection() as conn:
        sql = "SELECT * FROM produtos"
        if apenas_ativos:
            sql += " WHERE ativo=1"
        return [dict(linha) for linha in conn.execute(sql + " ORDER BY categoria,nome")]


@st.cache_data(ttl=20, max_entries=8, show_spinner=False)
def limites_vendas(incluir_canceladas=False):
    sql = "SELECT MIN(data),MAX(data) FROM compras WHERE data<=?"
    if not incluir_canceladas:
        sql += " AND cancelada_em IS NULL"
    with get_connection() as conn:
        menor, maior = conn.execute(sql, (date.today().isoformat(),)).fetchone()
    return tuple(date.fromisoformat(valor[:10]) if valor else None for valor in (menor, maior))


@st.cache_data(ttl=20, max_entries=64, show_spinner=False)
def listar_vendas(inicio, fim, incluir_canceladas=False):
    """Carrega apenas as compras do intervalo. O desconto inclui todos os itens da compra."""
    sql = """
        SELECT v.id,v.compra_id,c.data,v.produto_id,v.nome AS produto,v.categoria,
               v.qtde AS quantidade,v.unidade,v.preco AS preco_unitario,
               v.custo,v.custo_conhecido,c.desconto,c.forma_pagamento,c.operador,
               c.cliente,c.cancelada_em
        FROM compras c JOIN vendas v ON v.compra_id=c.id
        WHERE c.data BETWEEN ? AND ?
    """
    if not incluir_canceladas:
        sql += " AND c.cancelada_em IS NULL"
    with get_connection() as conn:
        df = pd.read_sql_query(
            sql + " ORDER BY c.data DESC,c.id DESC,v.id",
            conn, params=(inicio.isoformat(), fim.isoformat()),
        )
    df["data"] = pd.to_datetime(df["data"], format="ISO8601").dt.date
    df["bruto_cent"] = [
        total_item(qtd, preco) for qtd, preco in zip(df["quantidade"], df["preco_unitario"])
    ]
    df["custo_cent"] = pd.array([
        total_item(qtd, custo) if conhecido else None
        for qtd, custo, conhecido in zip(df["quantidade"], df["custo"], df["custo_conhecido"])
    ], dtype="Int64")
    rateios = [0] * len(df)
    for _, grupo in df.groupby("compra_id", sort=False):
        desconto = min(centavos(grupo["desconto"].iloc[0]), int(grupo["bruto_cent"].sum()))
        if desconto <= 0:
            continue
        bruto = int(grupo["bruto_cent"].sum())
        acumulado = 0
        anterior = 0
        # A divisão usa centavos inteiros e distribui exatamente o desconto total.
        for indice, valor in grupo["bruto_cent"].items():
            acumulado += int(valor)
            atual = (acumulado * desconto + bruto // 2) // bruto
            rateios[indice] = atual - anterior
            anterior = atual
    df["desconto_cent"] = rateios
    df["liquido_cent"] = df["bruto_cent"] - df["desconto_cent"]
    df["compra_total_cent"] = df.groupby("compra_id")["liquido_cent"].transform("sum")
    return df


def limpar_cache():
    listar_produtos.clear()
    listar_vendas.clear()
    limites_vendas.clear()


@st.cache_resource(show_spinner=False)
def preparar_banco(caminho, dia):
    """O cache evita executar a preparação a cada interação."""
    init_db()
    try:
        backup_diario()
    except (sqlite3.Error, OSError) as erro:
        return f"Não foi possível fazer o backup diário: {erro}"
    return None
