from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from pathlib import Path
import sqlite3
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import db
from csv_vendas import exportar_csv, importar_csv, ler_csv
from formatos import ErroMercado, brl, qtd_br, total_item
from operacoes import cancelar_compra, detalhes_compra, editar_compra, movimentar_estoque, registrar_compra, salvar_produto
from usuarios import autenticar, criar_usuario, listar_historico


class MercadoTest(unittest.TestCase):
    def setUp(self):
        pasta = self.enterContext(TemporaryDirectory())
        self.caminho = Path(pasta) / "mercado.db"
        self.enterContext(patch.object(db, "DB_PATH", self.caminho))
        db.limpar_cache()
        db.init_db()
        self.admin = criar_usuario("gerente", "Gerente", "senha-teste-01", "admin")
        self.caixa = criar_usuario("caixa", "Operador do caixa", "senha-teste-02", "caixa", self.admin)
        self.hoje = date.today()

    def tearDown(self):
        db.limpar_cache()

    def produto(self, nome, *, unidade="kg", saldo=1, valor=12.34):
        return salvar_produto(self.admin, nome=nome, categoria="Testes", unidade=unidade,
                              valor=valor, custo=3, controla=True, saldo=saldo, minimo=0)

    def saldo(self, produto_id):
        return next(p["estoque"] for p in db.listar_produtos() if p["id"] == produto_id)

    def compra(self, itens, token, desconto=0):
        return registrar_compra(self.caixa, itens, self.hoje, "Pix", desconto, "Cliente teste", token)

    def test_dados_originais_e_formatacao(self):
        self.assertEqual(len(db.listar_produtos()), 100)
        inicio, fim = db.limites_vendas()
        self.assertEqual(fim, date(2026, 10, 22))
        vendas = db.listar_vendas(inicio, fim)
        self.assertEqual(vendas["compra_id"].nunique(), 300)
        self.assertTrue(vendas["custo_cent"].notna().all())
        self.assertTrue(vendas["custo_conhecido"].all())
        self.assertTrue((vendas["custo"] > 0).all())
        with db.get_connection() as conn:
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM compras WHERE forma_pagamento='Não informado' OR operador='Não informado' OR cliente=''").fetchone()[0], 0)
        self.assertEqual(set(vendas.loc[vendas["produto"] == "Banana", "unidade"]), {"kg"})
        self.assertEqual(brl(1234.56), "R$ 1.234,56")
        self.assertEqual(qtd_br(0.350, "kg"), "0,350")
        self.assertEqual(total_item(0.35, 12.34), 432)

    def test_compra_com_varios_itens_edicao_e_cancelamento(self):
        peso = self.produto("Queijo de teste")
        un = self.produto("Pote de teste", unidade="un", saldo=5, valor=10)
        itens = [{"produto_id": peso, "quantidade": .350}, {"produto_id": un, "quantidade": 2}]
        compra_id = self.compra(itens, "check-1", 1)
        self.assertEqual(self.compra(itens, "check-1", 1), compra_id)
        self.assertEqual(self.saldo(peso), .650)
        self.assertEqual(self.saldo(un), 3)
        compra = detalhes_compra(compra_id)
        self.assertEqual(compra["total"], 2332)
        df = db.listar_vendas(self.hoje, self.hoje)
        self.assertEqual(int(df["liquido_cent"].sum()), 2332)
        self.assertEqual(int(df["desconto_cent"].sum()), 100)
        self.assertEqual(df["compra_id"].nunique(), 1)
        alteracoes = {i["id"]: (i["qtde"], i["preco"]) for i in compra["itens"]}
        alteracoes[compra["itens"][0]["id"]] = (.500, 12.34)
        with self.assertRaisesRegex(ErroMercado, "administrador"):
            editar_compra(self.caixa, compra_id, 0, self.hoje, "Pix", 1, "", alteracoes)
        editar_compra(self.admin, compra_id, 0, self.hoje, "Débito", 1, "", alteracoes)
        self.assertEqual(self.saldo(peso), .500)
        with self.assertRaisesRegex(ErroMercado, "outra sessão"):
            editar_compra(self.admin, compra_id, 0, self.hoje, "Pix", 1, "", alteracoes)
        cancelar_compra(self.admin, compra_id, 1)
        self.assertEqual(self.saldo(peso), 1)
        self.assertEqual(self.saldo(un), 5)
        self.assertEqual(len(db.listar_vendas(self.hoje, self.hoje)), 0)
        self.assertEqual(len(db.listar_vendas(self.hoje, self.hoje, True)), 2)
        self.assertIn("Editou compra", {x["acao"] for x in listar_historico(self.admin)})

    def test_transacao_inteira_e_desfazer_do_caixa(self):
        primeiro = self.produto("Primeiro")
        segundo = self.produto("Segundo")
        itens = [{"produto_id": primeiro, "quantidade": .25}, {"produto_id": segundo, "quantidade": 2}]
        with self.assertRaisesRegex(ErroMercado, "insuficiente"):
            self.compra(itens, "saldo")
        self.assertEqual(self.saldo(primeiro), 1)
        self.assertEqual(len(db.listar_vendas(self.hoje, self.hoje)), 0)
        itens.pop()
        with self.assertRaisesRegex(ErroMercado, "futuro"):
            registrar_compra(self.caixa, itens, self.hoje + timedelta(days=1), "Pix", 0, "", "futuro")
        compra = self.compra(itens, "desfazer")
        with self.assertRaises(ErroMercado):
            cancelar_compra(self.caixa, compra, 0)
        with self.assertRaises(ErroMercado):
            cancelar_compra(self.caixa, compra, 0, operacao="outra")
        cancelar_compra(self.caixa, compra, 0, operacao="desfazer")
        self.assertEqual(self.saldo(primeiro), 1)

    def test_falta_de_saldo_em_vendas_concorrentes(self):
        produto = self.produto("Concorrência")
        itens = [{"produto_id": produto, "quantidade": .750}]

        def tentar(token):
            try:
                self.compra(itens, token)
                return True
            except ErroMercado:
                return False

        with ThreadPoolExecutor(max_workers=2) as pool:
            resultados = list(pool.map(tentar, ["aba1", "aba2"]))
        self.assertEqual(sum(resultados), 1)
        self.assertEqual(self.saldo(produto), .250)

    def test_csv_agrupa_compras_e_reverte_erros(self):
        produto = self.produto("Produto CSV", saldo=2)
        compra = f"X;{self.hoje};Produto CSV;0,350;2,00;0,50;Pix"
        cabecalho = "compra_id;data;produto;quantidade;preco_unitario;desconto;forma_pagamento\n"
        conteudo = (cabecalho + compra + "\n" + compra + "\n").encode()
        self.assertEqual(importar_csv(self.admin, conteudo), 1)
        self.assertEqual(self.saldo(produto), 1.3)
        df = db.listar_vendas(self.hoje, self.hoje)
        self.assertEqual(int(df["liquido_cent"].sum()), 90)
        self.assertEqual(len(ler_csv(exportar_csv(df))), 1)
        with self.assertRaisesRegex(ErroMercado, "já foi importado"):
            importar_csv(self.admin, conteudo)
        linhas_invalidas = compra + "\n" + f"Y;{self.hoje};Inexistente;1;2;0;Pix\n"
        with self.assertRaisesRegex(ErroMercado, "não cadastrado"):
            importar_csv(self.admin, (cabecalho + linhas_invalidas).encode())
        self.assertEqual(self.saldo(produto), 1.3)
        self.assertEqual(len(db.listar_vendas(self.hoje, self.hoje)), 2)

    def test_catalogo_contas_e_backup(self):
        self.assertEqual(autenticar("GERENTE", "senha-teste-01"), self.admin)
        self.assertIsNone(autenticar("GERENTE", "senha-errada"))
        produto = self.produto("Produto de teste", unidade="un", saldo=1)
        with self.assertRaisesRegex(ErroMercado, "inteiros"):
            movimentar_estoque(self.admin, produto, "entrada", .350, "Compra")
        with self.assertRaisesRegex(ErroMercado, "administrador"):
            movimentar_estoque(self.caixa, produto, "entrada", 1, "Compra")
        self.assertEqual(movimentar_estoque(self.admin, produto, "entrada", 7, "Recebimento"), 8)
        copia = db.backup_manual()
        with sqlite3.connect(copia) as conn:
            self.assertEqual(conn.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(conn.execute("SELECT estoque FROM produtos WHERE id=?", (produto,)).fetchone()[0], 8)


class MigracaoTest(unittest.TestCase):
    def test_banco_antigo_preserva_venda_e_associa_compra(self):
        with TemporaryDirectory() as pasta:
            caminho = Path(pasta) / "original.db"
            with sqlite3.connect(caminho) as conn:
                conn.executescript("""
                    CREATE TABLE produtos(id INTEGER PRIMARY KEY,nome TEXT UNIQUE,categoria TEXT,valor REAL);
                    CREATE TABLE vendas(id INTEGER PRIMARY KEY,produto_id INTEGER,nome TEXT,categoria TEXT,
                                        qtde INTEGER,preco REAL,data DATE);
                    INSERT INTO produtos VALUES(111,'Banana','Hortifrúti',6.99);
                    INSERT INTO vendas VALUES(400,111,'Banana','Hortifrúti',3,5.99,'2026-10-22');
                """)
            with patch.object(db, "DB_PATH", caminho):
                db.init_db()
                db.init_db()
                with db.get_connection() as conn:
                    self.assertEqual(conn.execute("SELECT COUNT(*) FROM produtos").fetchone()[0], 1)
                    venda = conn.execute("SELECT compra_id,unidade,preco FROM vendas WHERE id=400").fetchone()
                    self.assertEqual(tuple(venda), (400, "kg", 5.99))
                    self.assertEqual(conn.execute("SELECT COUNT(*) FROM compras").fetchone()[0], 1)


if __name__ == "__main__":
    unittest.main()
