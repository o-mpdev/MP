from datetime import date
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

import db
from usuarios import criar_usuario


class InterfaceTest(unittest.TestCase):
    def setUp(self):
        pasta = self.enterContext(TemporaryDirectory())
        caminho = Path(pasta) / "mercado.db"
        self.enterContext(patch.object(db, "DB_PATH", caminho))
        db.preparar_banco.clear()
        db.limpar_cache()
        raiz = Path(__file__).resolve().parents[1]
        self.app = AppTest.from_file(str(raiz / "main.py"), default_timeout=15)

    def tearDown(self):
        db.limpar_cache()
        db.preparar_banco.clear()

    def botao(self, texto):
        return next(b for b in self.app.button if b.label == texto)

    def sem_erro(self):
        self.assertEqual([x.message for x in self.app.exception], [])
        self.assertEqual([x.value for x in self.app.error], [])

    def abrir(self, nome):
        self.app.switch_page(f"telas/{nome}.py").run()
        self.sem_erro()

    def entrar(self):
        self.app.run()
        self.sem_erro()
        for label, valor in (("Nome", "Gerente"), ("Usuário", "gerente"), ("Senha", "senha-teste-01")):
            next(input for input in self.app.text_input if input.label == label).set_value(valor)
        self.botao("Criar administrador e entrar").click().run()
        self.sem_erro()
        self.assertIn("Faturamento", [m.label for m in self.app.metric])

    def test_navegacao_nova_venda_e_desfazer(self):
        self.entrar()
        tabela = self.app.dataframe[0].value
        self.assertLessEqual(len(tabela), 10)
        self.assertTrue(tabela["Total líquido"].str.startswith("R$ ").all())

        self.abrir("cadastrar")
        next(x for x in self.app.text_input if x.label == "Buscar produto").set_value("banana").run()
        self.sem_erro()
        quantidade = next(x for x in self.app.number_input if x.label == "Quantidade (kg)")
        self.assertEqual(quantidade.value, .350)
        self.assertTrue(any("R$ 2,45" in x.value for x in self.app.markdown))
        quantidade.set_value(.500).run()
        self.assertTrue(any("R$ 3,50" in x.value for x in self.app.markdown))
        self.botao("Adicionar ao carrinho").click().run()
        self.assertIn(date.today(), [x.value for x in self.app.date_input])
        self.botao("Registrar compra").click().run()
        self.sem_erro()
        self.assertTrue(any("R$ 3,50" in x.value for x in self.app.success))
        self.botao("Confirmar que quero desfazer").click().run()
        self.sem_erro()
        self.assertTrue(any("desfeita" in x.value for x in self.app.success))

    def test_paginas_dashboard_antigo_e_admin(self):
        self.entrar()
        for page in ("vendas", "produtos", "dashboards", "administracao"):
            self.abrir(page)
        # Reproduz uma base em que o último dia de vendas está muito além dos 30 dias.
        with db.get_connection(escrita=True) as conn:
            conn.execute("UPDATE compras SET data=date(data,'-365 days')")
        db.limpar_cache()
        self.abrir("dashboards")
        self.assertEqual(next(x for x in self.app.radio if x.label == "Período").value, "Personalizado")
        fim = next(x for x in self.app.date_input if x.label == "Data final")
        self.assertEqual(fim.max, date.today())
        self.assertLess(fim.value, date.today())
        self.assertGreater(len(self.app.dataframe[0].value), 0)

    def test_confirmar_edicao_e_exclusao_na_linha(self):
        self.entrar()
        self.abrir("vendas")
        botao = self.botao("Editar")
        compra_id = int(botao.key.split("_")[-1])
        botao.click().run()
        self.sem_erro()
        self.botao("Salvar alterações").click().run()
        self.assertIn("Marque a confirmação antes de salvar.", [x.value for x in self.app.error])
        next(x for x in self.app.checkbox if x.label == "Confirmo as alterações desta compra.").check()
        self.botao("Salvar alterações").click().run()
        self.sem_erro()
        self.assertIn(f"Compra #{compra_id} atualizada.", [x.value for x in self.app.success])
        self.app.button(key=f"excluir_{compra_id}").click().run()
        self.assertTrue(self.botao("Confirmar cancelamento").disabled)
        next(x for x in self.app.checkbox if x.label == "Confirmo o cancelamento.").check().run()
        self.botao("Confirmar cancelamento").click().run()
        self.sem_erro()
        self.assertIn(f"Compra #{compra_id} cancelada.", [x.value for x in self.app.success])

    def test_caixa_tem_acesso_limitado(self):
        self.entrar()
        criar_usuario("caixa", "Caixa", "senha-teste-02", "caixa", self.app.session_state["usuario_id"])
        self.botao("Sair").click().run()
        self.assertNotIn("usuario_id", self.app.session_state)
        self.app.run()
        next(input for input in self.app.text_input if input.label == "Usuário").set_value("caixa")
        next(input for input in self.app.text_input if input.label == "Senha").set_value("senha-teste-02")
        self.botao("Entrar").click().run()
        self.sem_erro()
        self.abrir("vendas")
        self.assertNotIn("Editar", [b.label for b in self.app.button])
        self.abrir("produtos")
        self.assertNotIn("Cadastrar produto", [b.label for b in self.app.button])


if __name__ == "__main__":
    unittest.main()
