@echo off
setlocal
cd /d "%~dp0" || goto :erro_pasta

set "PANDAS_VENV=%~dp0.venv\Scripts\python.exe"
"%PANDAS_VENV%" -c "import sys; sys.exit(sys.version_info < (3, 11))" >nul 2>&1
if not errorlevel 1 goto :dependencias

set "PANDAS_PYTHON=python"
python -c "import sys; sys.exit(sys.version_info < (3, 11))" >nul 2>&1
if not errorlevel 1 goto :criar_ambiente

set "PANDAS_PYTHON=py -3"
py -3 -c "import sys; sys.exit(sys.version_info < (3, 11))" >nul 2>&1
if errorlevel 1 goto :erro_python

:criar_ambiente
echo Preparando o ambiente do Mercado Pandas...
%PANDAS_PYTHON% -m venv "%~dp0.venv"
if errorlevel 1 goto :erro_ambiente

:dependencias
"%PANDAS_VENV%" -c "import streamlit, pandas, plotly" >nul 2>&1
if not errorlevel 1 goto :iniciar
echo Instalando as dependencias do Mercado Pandas...
"%PANDAS_VENV%" -m pip install -r requirements.txt
if errorlevel 1 goto :erro_dependencias

:iniciar
"%PANDAS_VENV%" -m streamlit run main.py
if errorlevel 1 goto :erro_servidor
exit /b 0

:erro_pasta
echo Nao foi possivel abrir a pasta do projeto. Extraia o ZIP antes de iniciar.
goto :falhou

:erro_python
echo Instale o Python 3.11 ou mais recente e marque Add Python to PATH.
goto :falhou

:erro_ambiente
echo Nao foi possivel preparar o ambiente Python nesta pasta.
goto :falhou

:erro_dependencias
echo Nao foi possivel instalar as dependencias. Confira a internet e tente de novo.
goto :falhou

:erro_servidor
echo O Mercado Pandas encerrou com erro. Confira a mensagem acima.

:falhou
pause
exit /b 1
