"""Contas locais, permissões e registro das operações."""
import hashlib
import hmac
import re
import secrets
from datetime import datetime

from db import get_connection
from formatos import ErroMercado


def _senha_hash(senha, sal):
    return hashlib.scrypt(senha.encode("utf-8"), salt=sal, n=2**14, r=8, p=2).hex()


def _hash_novo(senha):
    if not 8 <= len(senha) <= 128:
        raise ErroMercado("A senha deve ter de 8 a 128 caracteres.")
    sal = secrets.token_bytes(16)
    return f"{sal.hex()}:{_senha_hash(senha, sal)}"


def momento():
    return datetime.now().isoformat(timespec="seconds")


def auditar(conn, usuario, acao, referencia, detalhe):
    conn.execute(
        """INSERT INTO historico(quando,usuario_id,operador,acao,referencia,detalhe)
           VALUES(?,?,?,?,?,?)""",
        (momento(), usuario["id"], usuario["nome"], acao, referencia, detalhe),
    )


def precisa_configurar():
    with get_connection() as conn:
        return conn.execute("SELECT 1 FROM usuarios LIMIT 1").fetchone() is None


def usuario_ativo(usuario_id, conn=None, *, admin=False):
    if conn is None:
        with get_connection() as leitura:
            return usuario_ativo(usuario_id, leitura, admin=admin)
    usuario = conn.execute(
        "SELECT id,login,nome,perfil FROM usuarios WHERE id=? AND ativo=1", (usuario_id,)
    ).fetchone()
    if usuario is None:
        raise ErroMercado("Entre com uma conta ativa para continuar.")
    if admin and usuario["perfil"] != "admin":
        raise ErroMercado("Esta operação exige a permissão de administrador.")
    return dict(usuario)


def autenticar(login, senha):
    if not 1 <= len(senha) <= 128:
        return None
    with get_connection() as conn:
        usuario = conn.execute(
            "SELECT * FROM usuarios WHERE login=? AND ativo=1", (login.strip().casefold(),)
        ).fetchone()
    if usuario is None:
        return None
    sal, esperado = usuario["senha_hash"].split(":", 1)
    if hmac.compare_digest(_senha_hash(senha, bytes.fromhex(sal)), esperado):
        return usuario["id"]
    return None


def criar_usuario(login, nome, senha, perfil, operador_id=None):
    login = login.strip().casefold()
    nome = nome.strip()
    if not re.fullmatch(r"[a-z0-9_.-]{3,32}", login):
        raise ErroMercado("Use de 3 a 32 letras sem acento, números, pontos, hífens ou sublinhados no usuário.")
    if not 1 <= len(nome) <= 80:
        raise ErroMercado("Informe um nome de exibição de até 80 caracteres.")
    if perfil not in ("admin", "caixa"):
        raise ErroMercado("Selecione um perfil válido.")
    senha_hash = _hash_novo(senha)
    with get_connection(escrita=True) as conn:
        if operador_id is None:
            if perfil != "admin" or conn.execute("SELECT 1 FROM usuarios LIMIT 1").fetchone():
                raise ErroMercado("O primeiro administrador já foi configurado. Faça login.")
            ator = None
        else:
            ator = usuario_ativo(operador_id, conn, admin=True)
        if conn.execute("SELECT 1 FROM usuarios WHERE login=?", (login,)).fetchone():
            raise ErroMercado("Esse nome de usuário já está em uso.")
        cursor = conn.execute(
            "INSERT INTO usuarios(login,nome,senha_hash,perfil) VALUES(?,?,?,?)",
            (login, nome, senha_hash, perfil),
        )
        novo_id = cursor.lastrowid
        auditar(conn, ator or {"id": novo_id, "nome": nome},
                "Criou conta", f"Usuário #{novo_id}", f"{login} · {perfil}")
        return novo_id


def listar_usuarios(operador_id):
    with get_connection() as conn:
        usuario_ativo(operador_id, conn, admin=True)
        return [dict(linha) for linha in conn.execute(
            "SELECT id,login,nome,perfil,ativo FROM usuarios ORDER BY login"
        )]


def atualizar_usuario(operador_id, usuario_id, ativo, nova_senha=""):
    senha_hash = _hash_novo(nova_senha) if nova_senha else None
    with get_connection(escrita=True) as conn:
        ator = usuario_ativo(operador_id, conn, admin=True)
        conta = conn.execute("SELECT login,ativo FROM usuarios WHERE id=?", (usuario_id,)).fetchone()
        if conta is None:
            raise ErroMercado("Conta não encontrada.")
        if operador_id == usuario_id and not ativo:
            raise ErroMercado("Sua conta de administrador deve permanecer ativa.")
        if bool(conta["ativo"]) == bool(ativo) and senha_hash is None:
            raise ErroMercado("Altere o status ou informe uma nova senha.")
        conn.execute(
            "UPDATE usuarios SET ativo=?,senha_hash=COALESCE(?,senha_hash) WHERE id=?",
            (int(ativo), senha_hash, usuario_id),
        )
        status = "conta ativa" if ativo else "conta desativada"
        if senha_hash is not None:
            status += ", senha redefinida"
        auditar(conn, ator, "Atualizou conta", f"Usuário #{usuario_id}", f"{conta['login']} · {status}")


def listar_historico(operador_id):
    with get_connection() as conn:
        usuario_ativo(operador_id, conn, admin=True)
        return [dict(linha) for linha in conn.execute(
            "SELECT quando,operador,acao,referencia,detalhe FROM historico ORDER BY id DESC LIMIT 200"
        )]
