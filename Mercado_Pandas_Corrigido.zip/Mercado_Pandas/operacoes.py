"""Regras de compra, catálogo e estoque. Cada alteração usa uma transação."""
from collections import Counter
from datetime import date

from db import get_connection, limpar_cache
from formatos import (
    PAGAMENTOS, UNIDADES, ErroMercado, brl, centavos, moeda, qtd_br,
    total_item, validar_quantidade, validar_valor,
)
from usuarios import auditar, momento, usuario_ativo


def _produto(conn, produto_id):
    produto = conn.execute("SELECT * FROM produtos WHERE id=?", (produto_id,)).fetchone()
    if produto is None:
        raise ErroMercado("Produto não encontrado.")
    return produto


def _textos(nome, categoria):
    nome, categoria = nome.strip(), categoria.strip()
    if not 1 <= len(nome) <= 100 or not 1 <= len(categoria) <= 60:
        raise ErroMercado("Preencha nome e categoria.")
    return nome, categoria


def salvar_produto(ator_id, *, nome, categoria, unidade, valor, custo, ativo=True,
                   controla=False, saldo=0, minimo=0, produto_id=None, revisao=None):
    nome, categoria = _textos(nome, categoria)
    if unidade not in UNIDADES:
        raise ErroMercado("Selecione uma unidade válida.")
    valor = validar_valor(valor, "O preço")
    custo_conhecido = custo is not None
    custo = validar_valor(custo if custo_conhecido else 0, "O custo")
    minimo = validar_quantidade(minimo, unidade, permite_zero=True)
    with get_connection(escrita=True) as conn:
        ator = usuario_ativo(ator_id, conn, admin=True)
        nomes = conn.execute("SELECT id,nome FROM produtos").fetchall()
        if any(p["nome"].casefold() == nome.casefold() and p["id"] != produto_id for p in nomes):
            raise ErroMercado("Já existe um produto com esse nome.")
        if produto_id is None:
            saldo = validar_quantidade(saldo, unidade, permite_zero=True)
            cursor = conn.execute("""INSERT INTO produtos
                (nome,categoria,unidade,valor,custo,custo_conhecido,ativo,controla_estoque,estoque,estoque_minimo)
                VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (nome, categoria, unidade, valor, custo, custo_conhecido, ativo, controla, saldo, minimo),
            )
            produto_id = cursor.lastrowid
            auditar(conn, ator, "Cadastrou produto", f"Produto #{produto_id}",
                    f"{nome} · {brl(valor)}/{unidade} · saldo inicial {qtd_br(saldo, unidade)} {unidade}")
        else:
            anterior = _produto(conn, produto_id)
            if anterior["revisao"] != revisao:
                raise ErroMercado("O produto foi alterado em outra sessão. Atualize e tente de novo.")
            if unidade != anterior["unidade"] and (
                anterior["estoque"] or conn.execute(
                    "SELECT 1 FROM vendas WHERE produto_id=? LIMIT 1", (produto_id,)
                ).fetchone()
            ):
                raise ErroMercado("A unidade só pode mudar em produtos sem vendas e com saldo zero.")
            conn.execute("""UPDATE produtos SET nome=?,categoria=?,unidade=?,valor=?,custo=?,
                custo_conhecido=?,ativo=?,controla_estoque=?,estoque_minimo=?,revisao=revisao+1 WHERE id=?""",
                (nome, categoria, unidade, valor, custo, custo_conhecido, ativo, controla, minimo, produto_id),
            )
            auditar(conn, ator, "Atualizou produto", f"Produto #{produto_id}",
                    f"{anterior['nome']} → {nome} · {brl(anterior['valor'])} → {brl(valor)} · "
                    f"{'ativo' if ativo else 'inativo'} · estoque {'controlado' if controla else 'livre'}")
    limpar_cache()
    return produto_id


def _alterar_saldo(conn, produto_id, variacao):
    produto = _produto(conn, produto_id)
    novo_saldo = round(produto["estoque"] + variacao, 3)
    if novo_saldo < 0:
        unidade = produto["unidade"]
        raise ErroMercado(
            f"Estoque insuficiente para {produto['nome']}. "
            f"Disponível: {qtd_br(produto['estoque'], unidade)} {unidade}."
        )
    conn.execute("UPDATE produtos SET estoque=? WHERE id=?", (novo_saldo, produto_id))
    return novo_saldo


def movimentar_estoque(ator_id, produto_id, modo, quantidade, motivo):
    motivo = motivo.strip()
    if modo not in ("entrada", "ajuste") or not 1 <= len(motivo) <= 160:
        raise ErroMercado("Informe a operação e o motivo da movimentação.")
    with get_connection(escrita=True) as conn:
        ator = usuario_ativo(ator_id, conn, admin=True)
        produto = _produto(conn, produto_id)
        unidade = produto["unidade"]
        quantidade = validar_quantidade(quantidade, unidade, permite_zero=modo == "ajuste")
        variacao = quantidade if modo == "entrada" else quantidade - produto["estoque"]
        saldo = _alterar_saldo(conn, produto_id, variacao)
        auditar(conn, ator, "Movimentou estoque", f"Produto #{produto_id}",
                f"{produto['nome']} · {modo} · {qtd_br(produto['estoque'], unidade)} → "
                f"{qtd_br(saldo, unidade)} {unidade} · {motivo}")
    limpar_cache()
    return saldo


def _dados_compra(dia, pagamento, desconto, cliente, subtotal):
    if not isinstance(dia, date) or dia > date.today():
        raise ErroMercado("A data da venda não pode estar no futuro.")
    if pagamento not in PAGAMENTOS:
        raise ErroMercado("Informe uma forma de pagamento válida.")
    desconto = validar_valor(desconto, "O desconto")
    if centavos(desconto) > subtotal:
        raise ErroMercado(f"O desconto não pode superar o subtotal de {moeda(subtotal)}.")
    cliente = cliente.strip()
    if len(cliente) > 100:
        raise ErroMercado("Informe um nome de cliente de até 100 caracteres.")
    return (dia.isoformat(), desconto, pagamento, cliente)


def preparar_itens(conn, pedidos, *, importacao=False):
    if not pedidos:
        raise ErroMercado("Adicione pelo menos um item.")
    itens = []
    for pedido in pedidos:
        atual = _produto(conn, pedido["produto_id"])
        if not atual["ativo"]:
            raise ErroMercado(f"{atual['nome']} está inativo.")
        unidade = atual["unidade"]
        qtd = validar_quantidade(pedido["quantidade"], unidade)
        if importacao:
            if pedido.get("unidade", unidade) != unidade:
                raise ErroMercado(f"A unidade de {atual['nome']} no CSV difere do catálogo.")
            preco = validar_valor(pedido.get("preco", atual["valor"]), "O preço unitário")
            custo = pedido.get("custo", atual["custo"] if atual["custo_conhecido"] else None)
            custo = validar_valor(custo, "O custo") if custo is not None else None
        else:
            preco = atual["valor"]
            if pedido.get("preco", preco) != preco or pedido.get("unidade", unidade) != unidade:
                raise ErroMercado(f"O preço ou a unidade de {atual['nome']} mudou. Remova o item e adicione novamente.")
            custo = atual["custo"] if atual["custo_conhecido"] else None
        itens.append({
            "produto_id": atual["id"], "nome": atual["nome"], "categoria": atual["categoria"],
            "unidade": unidade, "quantidade": qtd, "preco": preco,
            "custo": custo, "baixado": qtd if atual["controla_estoque"] else 0,
        })
    return itens


def inserir_compra(conn, ator, itens, dia, pagamento, desconto, cliente, operacao=None, *, origem=""):
    subtotal = sum(total_item(i["quantidade"], i["preco"]) for i in itens)
    data_sql, desconto, pagamento, cliente = _dados_compra(dia, pagamento, desconto, cliente, subtotal)
    baixa = Counter()
    for item in itens:
        baixa[item["produto_id"]] += item["baixado"]
    for produto_id, variacao in baixa.items():
        if variacao:
            _alterar_saldo(conn, produto_id, -variacao)

    cursor = conn.execute("""INSERT INTO compras
        (data,desconto,forma_pagamento,cliente,operador,usuario_id,criada_em,operacao)
        VALUES(?,?,?,?,?,?,?,?)""",
        (data_sql, desconto, pagamento, cliente, ator["nome"], ator["id"], momento(), operacao),
    )
    compra_id = cursor.lastrowid
    conn.executemany("""INSERT INTO vendas
        (compra_id,produto_id,nome,categoria,qtde,unidade,preco,custo,custo_conhecido,estoque_baixado,data)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""", [
        (compra_id, i["produto_id"], i["nome"], i["categoria"], i["quantidade"], i["unidade"],
         i["preco"], i["custo"] or 0, i["custo"] is not None, i["baixado"], data_sql)
        for i in itens
    ])
    auditar(conn, ator, "Registrou compra", f"Compra #{compra_id}",
            f"{len(itens)} item(ns) · {moeda(subtotal - centavos(desconto))} · {pagamento}{origem}")
    return compra_id


def registrar_compra(ator_id, pedidos, dia, pagamento, desconto, cliente, operacao):
    with get_connection(escrita=True) as conn:
        ator = usuario_ativo(ator_id, conn)
        existente = conn.execute("SELECT id,usuario_id FROM compras WHERE operacao=?", (operacao,)).fetchone()
        if existente:
            if existente["usuario_id"] != ator_id:
                raise ErroMercado("A operação já foi registrada.")
            return existente["id"]
        itens = preparar_itens(conn, pedidos)
        compra_id = inserir_compra(conn, ator, itens, dia, pagamento, desconto, cliente, operacao)
    limpar_cache()
    return compra_id


def _compra(conn, compra_id):
    compra = conn.execute("SELECT * FROM compras WHERE id=?", (compra_id,)).fetchone()
    if compra is None:
        raise ErroMercado("Compra não encontrada.")
    return compra


def detalhes_compra(compra_id):
    with get_connection() as conn:
        compra = dict(_compra(conn, compra_id))
        itens = [dict(row) for row in conn.execute(
            "SELECT * FROM vendas WHERE compra_id=? ORDER BY id", (compra_id,)
        )]
    compra["itens"] = itens
    compra["subtotal"] = sum(total_item(i["qtde"], i["preco"]) for i in itens)
    compra["total"] = compra["subtotal"] - centavos(compra["desconto"])
    return compra


def _conferir_compra(compra, revisao):
    if compra["cancelada_em"]:
        raise ErroMercado("A compra já está cancelada.")
    if compra["revisao"] != revisao:
        raise ErroMercado("A compra mudou em outra sessão. Atualize e tente de novo.")


def editar_compra(ator_id, compra_id, revisao, dia, pagamento, desconto, cliente, alteracoes):
    with get_connection(escrita=True) as conn:
        ator = usuario_ativo(ator_id, conn, admin=True)
        compra = _compra(conn, compra_id)
        _conferir_compra(compra, revisao)
        itens = conn.execute("SELECT * FROM vendas WHERE compra_id=? ORDER BY id", (compra_id,)).fetchall()
        if set(alteracoes) != {item["id"] for item in itens}:
            raise ErroMercado("Os itens da compra mudaram. Abra a edição novamente.")

        ajustes = Counter()
        novos = []
        resumo = []
        for item in itens:
            qtde, preco = alteracoes[item["id"]]
            qtde = validar_quantidade(qtde, item["unidade"], permite_zero=True)
            preco = validar_valor(preco, "O preço unitário")
            produto = _produto(conn, item["produto_id"])
            antigo = item["estoque_baixado"]
            baixado = min(qtde, antigo)
            if produto["controla_estoque"]:
                baixado += max(0, round(qtde - item["qtde"], 3))
            ajustes[item["produto_id"]] += antigo - baixado
            novos.append((item["id"], qtde, preco, baixado))
            if qtde != item["qtde"] or preco != item["preco"]:
                resumo.append(f"{item['nome']} {item['qtde']:g} → {qtde:g}, {brl(item['preco'])} → {brl(preco)}")
        if not any(qtde for _, qtde, _, _ in novos):
            raise ErroMercado("Mantenha pelo menos um item ou cancele a compra inteira.")
        subtotal = sum(total_item(qtde, preco) for _, qtde, preco, _ in novos)
        dados = _dados_compra(dia, pagamento, desconto, cliente, subtotal)

        for produto_id, variacao in ajustes.items():
            if round(variacao, 3):
                _alterar_saldo(conn, produto_id, variacao)
        conn.execute("""UPDATE compras SET data=?,desconto=?,forma_pagamento=?,cliente=?,
                     revisao=revisao+1 WHERE id=?""", (*dados, compra_id))
        for item_id, qtde, preco, baixado in novos:
            if qtde == 0:
                conn.execute("DELETE FROM vendas WHERE id=?", (item_id,))
            else:
                conn.execute("UPDATE vendas SET qtde=?,preco=?,estoque_baixado=?,data=? WHERE id=?",
                             (qtde, preco, round(baixado, 3), dados[0], item_id))
        auditar(conn, ator, "Editou compra", f"Compra #{compra_id}",
                f"{compra['data']} → {dados[0]} · {compra['forma_pagamento']} → {pagamento} · "
                f"Desconto {brl(compra['desconto'])} → {brl(desconto)} · "
                f"Total {moeda(subtotal - centavos(desconto))} "
                + ("· " + " | ".join(resumo) if resumo else ""))
    limpar_cache()


def cancelar_compra(ator_id, compra_id, revisao, *, operacao=None):
    with get_connection(escrita=True) as conn:
        ator = usuario_ativo(ator_id, conn, admin=operacao is None)
        compra = _compra(conn, compra_id)
        if operacao is not None and (compra["usuario_id"], compra["operacao"]) != (ator_id, operacao):
            raise ErroMercado("Apenas a própria compra recente pode ser desfeita no caixa.")
        _conferir_compra(compra, revisao)
        itens = conn.execute(
            "SELECT produto_id,SUM(estoque_baixado) AS baixa FROM vendas WHERE compra_id=? GROUP BY produto_id",
            (compra_id,),
        )
        for item in itens:
            if item["baixa"]:
                _alterar_saldo(conn, item["produto_id"], item["baixa"])
        conn.execute("UPDATE compras SET cancelada_em=?,revisao=revisao+1 WHERE id=?", (momento(), compra_id))
        acao = "Desfez compra" if operacao is not None else "Cancelou compra"
        auditar(conn, ator, acao, f"Compra #{compra_id}", "Os itens que baixaram saldo foram devolvidos.")
    limpar_cache()
