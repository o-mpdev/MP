"""Importa e exporta vendas, incluindo compras de vários itens."""
import csv
import hashlib
import io
from datetime import date, datetime

from db import get_connection, limpar_cache
from formatos import ErroMercado, decimal
from operacoes import inserir_compra, preparar_itens
from usuarios import auditar, usuario_ativo


def _data(texto):
    try:
        return date.fromisoformat(texto)
    except ValueError:
        return datetime.strptime(texto, "%d/%m/%Y").date()


def _numero(texto):
    if "," in texto:
        texto = texto.replace(".", "").replace(",", ".")
    return decimal(texto)


def ler_csv(conteudo):
    if not conteudo or len(conteudo) > 5_000_000:
        raise ErroMercado("Selecione um CSV com dados e até 5 MB.")
    try:
        texto = conteudo.decode("utf-8-sig")
    except UnicodeDecodeError as erro:
        raise ErroMercado("Salve o arquivo como CSV UTF-8 e tente novamente.") from erro

    if not texto.strip():
        raise ErroMercado("O CSV não contém vendas.")
    cabecalho = texto.splitlines()[0]
    leitor = csv.DictReader(io.StringIO(texto), delimiter=";" if ";" in cabecalho else ",")
    leitor.fieldnames = [campo.strip().lower() for campo in (leitor.fieldnames or [])]
    if not {"data", "produto", "quantidade"}.issubset(leitor.fieldnames):
        raise ErroMercado("O CSV precisa das colunas data, produto e quantidade.")
    if len(leitor.fieldnames) != len(set(leitor.fieldnames)):
        raise ErroMercado("Remova os nomes de colunas duplicados.")
    grupos = {}
    try:
        for linha in leitor:
            numero = leitor.line_num
            if numero > 10001:
                raise ErroMercado("Importe no máximo 10 mil linhas de cada vez.")
            if None in linha or any(valor is None for valor in linha.values()):
                raise ErroMercado(f"Linha {numero}: confira a quantidade de colunas.")
            linha = {k: v.strip() for k, v in linha.items()}
            chave = linha.get("compra_id", "")
            chave = ("compra", chave) if chave else ("linha", numero)
            try:
                dia = _data(linha["data"])
                if dia > date.today():
                    raise ErroMercado("A data da venda está no futuro.")
                compra = grupos.setdefault(chave, {"linha": numero, "itens": []})
                dados = (dia, linha.get("forma_pagamento") or "Não informado",
                         _numero(linha.get("desconto") or "0"), linha.get("cliente", ""))
                if compra.setdefault("dados", dados) != dados:
                    raise ErroMercado("Itens de uma compra devem ter os mesmos dados de pagamento, data, desconto e cliente.")
                item = {"nome": linha["produto"], "quantidade": _numero(linha["quantidade"])}
                if linha.get("preco_unitario"):
                    item["preco"] = _numero(linha["preco_unitario"])
                if "custo" in linha:
                    item["custo"] = _numero(linha["custo"]) if linha["custo"] else None
                if linha.get("unidade"):
                    item["unidade"] = linha["unidade"]
                compra["itens"].append(item)
            except ValueError as erro:
                mensagem = str(erro) if isinstance(erro, ErroMercado) else "Data inválida. Use AAAA-MM-DD ou DD/MM/AAAA."
                raise ErroMercado(f"Linha {numero}: {mensagem}") from erro
    except csv.Error as erro:
        raise ErroMercado("Não foi possível ler o formato do CSV.") from erro
    if not grupos:
        raise ErroMercado("O CSV não contém vendas.")
    return list(grupos.values())


def importar_csv(ator_id, conteudo):
    compras = ler_csv(conteudo)
    assinatura = hashlib.sha256(conteudo).hexdigest()
    with get_connection(escrita=True) as conn:
        ator = usuario_ativo(ator_id, conn, admin=True)
        if conn.execute("SELECT 1 FROM importacoes WHERE assinatura=?", (assinatura,)).fetchone():
            raise ErroMercado("Este arquivo já foi importado.")
        produtos = {p["nome"].casefold(): p["id"] for p in conn.execute("SELECT id,nome FROM produtos")}
        for compra in compras:
            try:
                for item in compra["itens"]:
                    produto_id = produtos.get(item["nome"].casefold())
                    if produto_id is None:
                        raise ErroMercado(f"Produto não cadastrado: {item['nome']}.")
                    item["produto_id"] = produto_id
                itens = preparar_itens(conn, compra["itens"], importacao=True)
                inserir_compra(conn, ator, itens, *compra["dados"], origem=" · importação CSV")
            except ErroMercado as erro:
                raise ErroMercado(f"Compra iniciada na linha {compra['linha']}: {erro}") from erro
        conn.execute("INSERT INTO importacoes(assinatura,compras) VALUES(?,?)", (assinatura, len(compras)))
        auditar(conn, ator, "Importou vendas", "Arquivo CSV", f"{len(compras)} compra(s)")
    limpar_cache()
    return len(compras)


def exportar_csv(df):
    """Exporta o desconto correspondente aos itens filtrados, em centavos exatos."""
    arquivo = io.StringIO()
    escritor = csv.writer(arquivo, delimiter=";")
    escritor.writerow([
        "compra_id", "data", "produto", "categoria", "quantidade", "unidade", "preco_unitario",
        "custo", "desconto", "forma_pagamento", "cliente", "operador",
    ])
    descontos = df.groupby("compra_id")["desconto_cent"].sum()
    for item in df.itertuples(index=False):
        escritor.writerow([
            item.compra_id, item.data.isoformat(), item.produto, item.categoria,
            f"{item.quantidade:g}", item.unidade, f"{item.preco_unitario:.2f}",
            f"{item.custo:.2f}" if item.custo_conhecido else "",
            f"{descontos[item.compra_id] / 100:.2f}", item.forma_pagamento,
            item.cliente, item.operador,
        ])
    return arquivo.getvalue().encode("utf-8-sig")
