# Guia de apresentação — Mercado Pandas

## 1. Visão geral do programa

O Mercado Pandas é um sistema de gerenciamento de mercado feito em Python com Streamlit e SQLite. Ele permite cadastrar produtos, controlar estoque, registrar compras, consultar vendas, acompanhar indicadores e administrar usuários.

### Fluxo principal
1. O usuário abre o programa e entra com sua conta.
2. O Streamlit apresenta as páginas permitidas ao perfil (Administrador ou Caixa).
3. Na venda, o operador escolhe produtos, quantidades e forma de pagamento.
4. A camada de operações valida os dados e grava a compra no SQLite.
5. As páginas consultam o banco para montar tabelas, histórico e gráficos.

### Tecnologias
- **Python:** linguagem e regras do sistema.
- **Streamlit:** interface web e navegação entre telas.
- **SQLite:** banco de dados local em arquivo.
- **Pandas:** organização e análise dos dados.
- **Plotly:** gráficos dos dashboards.
- **JSON:** catálogo e histórico de demonstração usados na primeira criação do banco.

## 2. Divisão da apresentação entre as quatro pessoas

A divisão abaixo evita que todos expliquem a mesma coisa. Cada integrante deve dominar sua parte e saber explicar como ela se conecta às demais.

---

## Nicolas — Navegação, estrutura visual e experiência de uso

**Arquivos principais:** `main.py`, `interface.py`, `telas/inicio.py`, `telas/dashboards.py` e `telas/administracao.py` (parte visual).

### O que explicar
- `main.py` é o ponto de entrada. Configura a página, prepara o banco, verifica a sessão e decide quais páginas aparecem.
- `st.navigation` e `st.Page` montam o menu lateral.
- O perfil controla o acesso: Administrador vê Administração; Caixa não recebe essa página.
- `interface.py` reúne componentes reaproveitados: busca de produto, campo de quantidade, tabelas, mensagens e tratamento de erros.
- A tela inicial apresenta um resumo; o dashboard transforma as vendas em indicadores e gráficos.
- A tela de Administração apresenta usuários, histórico e opção de backup.

### Demonstração sugerida
1. Abrir o programa e mostrar a tela de login.
2. Entrar e percorrer o menu.
3. Mostrar a diferença entre os perfis Administrador e Caixa.
4. Abrir a Visão geral e o Dashboard; alterar o período ou filtros.
5. Mostrar a área de Administração.

### Perguntas que precisa saber responder
- **Por que usar `interface.py`?** Para não repetir os mesmos componentes e regras visuais em várias telas.
- **Como o menu muda?** A lista de páginas é montada conforme o perfil da conta.
- **Onde os dados dos gráficos são calculados?** As consultas vêm de `db.py`; a preparação visual e os gráficos ficam nas telas e funções auxiliares.

---

## Wagner — Telas operacionais: produtos e vendas

**Arquivos principais:** `telas/produtos.py`, `telas/cadastrar.py` e `telas/vendas.py`.

### O que explicar
- `produtos.py` lista o catálogo, mostra preço, custo e estoque e permite ao Administrador cadastrar, editar e movimentar estoque.
- `cadastrar.py` é o fluxo de nova venda: escolher produto, informar quantidade, adicionar ao carrinho, aplicar desconto e registrar a compra.
- O carrinho fica temporariamente na sessão do Streamlit; ele não é o banco de dados.
- `vendas.py` filtra compras por período e produto, mostra os itens de cada compra e permite ao Administrador editar ou cancelar.
- Cancelar uma compra não apaga o histórico: a compra fica marcada como cancelada e o estoque baixado é devolvido.
- As telas chamam funções de `operacoes.py`; elas não devem executar SQL diretamente.

### Demonstração sugerida
1. Abrir Produtos e localizar um item pela categoria ou busca.
2. Mostrar preço, custo e situação do estoque.
3. Abrir Nova venda, adicionar dois produtos e explicar o subtotal.
4. Mostrar desconto, forma de pagamento e confirmação do registro.
5. Abrir Vendas, localizar a compra e mostrar seus detalhes.
6. Explicar a diferença entre editar e cancelar.

### Perguntas que precisa saber responder
- **O carrinho já é salvo no banco?** Não. Ele é mantido na sessão até o registro da compra.
- **O que acontece ao registrar?** A camada de operações valida os itens, grava compra e itens e atualiza o estoque na mesma transação.
- **Por que cancelar em vez de apagar?** Para preservar rastreabilidade e histórico.

---

## Victor — Banco de dados e persistência

**Arquivos principais:** `db.py`, `dados_iniciais.json`, `backup.py` e a parte de persistência de `csv_vendas.py`.

### O que explicar
- O banco é SQLite e fica no arquivo `bd_pandas.db` (criado na primeira execução).
- `db.py` define as tabelas, abre conexões, ativa chaves estrangeiras, prepara/migra a estrutura e oferece consultas.
- Tabelas centrais:
  - `produtos`: catálogo, preço, custo e dados de estoque.
  - `usuarios`: login, nome, hash da senha, perfil e status.
  - `compras`: cabeçalho da compra, data, desconto, pagamento, operador e cliente.
  - `vendas`: itens de cada compra, com produto, quantidade, preço e custo registrado na época.
  - `historico`: auditoria das operações administrativas.
  - `importacoes`: evita importar o mesmo CSV mais de uma vez.
- Uma compra pode ter vários itens: `compras.id` se relaciona com `vendas.compra_id`.
- As chaves estrangeiras protegem relações entre registros.
- `BEGIN IMMEDIATE` reserva a escrita antes de validar e atualizar o estoque, reduzindo risco de duas vendas concorrentes consumirem o mesmo saldo.
- `dados_iniciais.json` alimenta o banco na primeira inicialização; não é o banco usado durante o funcionamento normal.
- O backup usa a API de backup do SQLite para copiar o banco de forma consistente.

### Atenção sobre os dados de demonstração
O catálogo e as 300 compras são dados fictícios para demonstração. Os custos foram estimados como valores plausíveis a partir dos preços de venda, e nomes de operadores/clientes são fictícios. Não são registros contábeis nem custos reais de fornecedores. O custo fica gravado também em cada item vendido para preservar o custo histórico usado no relatório.

### Demonstração sugerida
1. Mostrar `dados_iniciais.json` e explicar que ele é a carga inicial.
2. Mostrar no `db.py` a criação das tabelas e os relacionamentos.
3. Explicar a relação `compras` → `vendas`.
4. Mostrar o arquivo `bd_pandas.db` criado após iniciar o programa (se houver ferramenta SQLite disponível).
5. Explicar backup e histórico.

### Perguntas que precisa saber responder
- **Por que separar compra e venda?** A compra guarda dados gerais; vendas guarda cada item. Assim uma compra pode conter vários produtos.
- **O JSON é o banco?** Não. Ele só inicializa uma base nova.
- **Por que guardar custo em `vendas`?** Para não alterar o custo histórico de uma venda quando o cadastro do produto mudar.

---

## MP — Regras de negócio, validações e segurança

**Arquivos principais:** `operacoes.py`, `formatos.py`, `usuarios.py` e `tests/`.

### O que explicar
- `operacoes.py` concentra as regras que não devem ficar espalhadas nas telas: salvar produto, movimentar estoque, preparar itens, registrar compra, editar e cancelar compra.
- Antes de gravar, o programa valida quantidade, preço, desconto, estoque disponível, permissões e revisão do registro.
- A gravação de uma compra e a baixa do estoque acontecem dentro de uma transação. Se uma etapa falhar, a transação é revertida.
- O token da operação evita registrar a mesma compra duas vezes em situações de repetição.
- A revisão do registro ajuda a impedir que uma edição antiga sobrescreva uma alteração mais recente.
- `formatos.py` centraliza validações numéricas, arredondamento em centavos e formatação brasileira.
- `usuarios.py` cuida da autenticação, criação de contas, permissões e auditoria. As senhas são armazenadas com hash usando `scrypt`, não em texto puro.
- Os testes automatizados verificam vendas, edição, cancelamento, concorrência, CSV, usuários e backup.

### Demonstração sugerida
1. Mostrar em `formatos.py` a validação de quantidade por unidade (`kg` aceita três casas; `un` e `dz` exigem inteiros).
2. Mostrar em `operacoes.py` o registro de compra e a atualização do estoque.
3. Explicar o tratamento de erro e o rollback da transação.
4. Mostrar em `usuarios.py` o hash da senha e a verificação de perfil.
5. Executar os testes automatizados no ambiente com as dependências instaladas.

### Perguntas que precisa saber responder
- **Por que a regra não fica na tela?** Para centralizar a lógica, evitar duplicação e permitir testar sem depender da interface.
- **O que é uma transação?** Um conjunto de operações que é confirmado por inteiro ou desfeito por inteiro.
- **Como evita venda duplicada?** Usa um identificador/token único da operação.
- **Como protege as senhas?** Guarda um hash com salt via `scrypt`, e compara o hash no login.

---

## 3. Como iniciar e apresentar o programa

1. Instalar as dependências listadas em `requirements.txt`.
2. Executar `Iniciar_Mercado_Pandas.cmd` no Windows ou usar `python -m streamlit run main.py` dentro da pasta do projeto.
3. No primeiro acesso, criar o primeiro Administrador. Não existe senha padrão embutida.
4. Criar uma conta Caixa pela tela Administração para demonstrar permissões.
5. Fazer uma venda de teste e mostrar o registro em Vendas.
6. Se for usar o banco real de demonstração, fazer uma cópia de segurança antes de testar alterações.

## 4. Comandos úteis para a equipe

```bash
# Instalar dependências
python -m pip install -r requirements.txt

# Iniciar o sistema
python -m streamlit run main.py

# Executar os testes de lógica e banco
python -m unittest discover -s tests -v
```

Os testes precisam ser executados no mesmo ambiente em que as dependências do projeto estão instaladas.

## 5. Limites que não devem ser escondidos na apresentação

- Os dados carregados são fictícios e servem para demonstrar funcionalidades.
- Custos estimados não substituem notas fiscais nem dados de fornecedores.
- O sistema usa um banco SQLite local; não é uma solução multi-loja ou hospedada em servidor.
- O backup é local. Para uso real, seria necessário definir política de cópia externa, controle de acesso ao arquivo e recuperação testada.
- A conta Administrador inicial é criada pelo primeiro usuário; a equipe deve configurar uma senha forte na demonstração.
