from datetime import date
from pathlib import Path
import sqlite3

import streamlit as st

from db import DB_PATH, preparar_banco
from formatos import ErroMercado
from interface import tratar_erros
from usuarios import autenticar, criar_usuario, precisa_configurar, usuario_ativo

st.set_page_config(page_title="Mercado Pandas", page_icon="🛒", layout="wide",
                   initial_sidebar_state="expanded")
st.logo(str(Path(__file__).with_name("panda logo.png")))

# A aparência acompanha o tema escolhido no Streamlit.
st.markdown("""
<style>
[data-testid="stMetric"] { border-radius: 12px; padding: 14px; }
.stButton > button { border-radius: 8px; }
</style>
""", unsafe_allow_html=True)

try:
    problema_backup = preparar_banco(str(DB_PATH), date.today())
except (sqlite3.Error, OSError, RuntimeError):
    st.error("Não foi possível abrir o banco do Mercado Pandas. Confira a pasta e a versão do banco.")
    st.stop()

conta = None
primeiro_acesso = False


def limpar_sessao():
    # Mantém os widgets do Streamlit e limpa somente os dados do operador.
    for chave in ("usuario_id", "conta", "carrinho", "comprovante", "token_compra", "aviso_mercado", "acao_vendas"):
        st.session_state.pop(chave, None)


with tratar_erros():
    if st.session_state.get("usuario_id"):
        try:
            conta = usuario_ativo(st.session_state.usuario_id)
        except ErroMercado:
            limpar_sessao()
            st.warning("Sua sessão foi encerrada. Entre novamente.")
    primeiro_acesso = not conta and precisa_configurar()


def tela_login():
    st.title("🛒 Mercado Pandas")
    st.caption("Configure o primeiro administrador." if primeiro_acesso else "Entre para abrir o sistema.")
    with st.form("conta", clear_on_submit=True):
        nome = st.text_input("Nome", max_chars=80) if primeiro_acesso else ""
        login = st.text_input("Usuário", max_chars=32)
        senha = st.text_input("Senha", type="password", max_chars=128)
        if primeiro_acesso:
            st.caption("Use uma senha com pelo menos 8 caracteres.")
        entrar = st.form_submit_button("Criar administrador e entrar" if primeiro_acesso else "Entrar",
                                       type="primary")
    if entrar:
        with tratar_erros():
            usuario_id = criar_usuario(login, nome, senha, "admin") if primeiro_acesso else autenticar(login, senha)
            if usuario_id is None:
                st.error("Usuário ou senha inválidos.")
            else:
                st.session_state.usuario_id = usuario_id
                st.rerun()


if not conta:
    st.navigation([st.Page(tela_login, title="Entrar", default=True)], position="hidden").run()
    st.stop()

st.session_state.conta = conta
admin = conta["perfil"] == "admin"
paginas = [
    st.Page("telas/inicio.py", title="Visão geral", icon="🏠", default=True),
    st.Page("telas/cadastrar.py", title="Nova venda", icon="➕"),
    st.Page("telas/vendas.py", title="Vendas", icon="🧾"),
    st.Page("telas/produtos.py", title="Produtos", icon="📦"),
    st.Page("telas/dashboards.py", title="Dashboards", icon="📊"),
]
if admin:
    paginas.append(st.Page("telas/administracao.py", title="Administração", icon="⚙️"))

with tratar_erros():
    pagina = st.navigation(paginas)
    esquerda, direita = st.columns([5, 1], vertical_alignment="center")
    esquerda.caption(f'{conta["nome"]} · {"Administrador" if admin else "Caixa"}')
    direita.button("Sair", key="sair_mercado", on_click=limpar_sessao)
    if admin and problema_backup:
        st.warning(problema_backup)
    pagina.run()
