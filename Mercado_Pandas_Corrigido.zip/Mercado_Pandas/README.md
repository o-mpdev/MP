# Mercado Pandas

Sistema local de mercado em Python, Streamlit, Pandas, Plotly e SQLite.

## Abrir no Windows

1. Extraia o ZIP e entre na pasta `Mercado_Pandas`.
2. Com Python 3.11 ou mais recente, abra `Iniciar_Mercado_Pandas.cmd` com dois cliques.
3. No primeiro acesso, crie o administrador na tela. Escolha seu nome, usuário e senha. Depois use essas credenciais para entrar.

Na primeira execução, o inicializador instala as dependências pela internet. Deixe a janela aberta enquanto usa o sistema no navegador. Se a página não abrir automaticamente, use [http://127.0.0.1:8501](http://127.0.0.1:8501).

### Pelo VS Code

Abra a pasta `Mercado_Pandas`. No PowerShell integrado execute:

```powershell
.\Iniciar_Mercado_Pandas.cmd
```

Para iniciar manualmente, use `python -m pip install -r requirements.txt` e `python -m streamlit run main.py`.

## Vendas, estoque e relatórios

- **Nova venda** monta a compra com vários produtos. Para produtos em kg, é possível vender a partir de 0,001 kg. O cupom simples pode ser baixado em TXT. A última compra registrada nessa sessão pode ser desfeita.
- **Vendas** filtra compras por data e produto. O administrador pode editar a data, os dados da compra e as quantidades ou preços dos itens. Excluir cancela a compra inteira, devolve ao saldo a quantidade que foi baixada e registra a operação no histórico.
- **Produtos** permite gerenciar o catálogo, definir preço, informar custo e receber mercadorias ou ajustar o saldo de uma contagem. O estoque controlado bloqueia vendas sem saldo. Cadastros novos têm o controle ativado por padrão.
- **Dashboards** mostra faturamento líquido, ticket por compra e comparação com o período anterior. Custo e margem usam os itens com custo registrado. As quantidades são comparadas dentro da mesma unidade.
- **Administração** gerencia acessos, mostra as últimas 200 operações e cria uma cópia manual do banco. A conta de caixa registra, consulta e desfaz sua última compra. Operações administrativas exigem o perfil administrador.

## Banco existente e backup

Na primeira execução sem banco, o sistema cria `bd_pandas.db` com os 100 produtos e as 300 vendas do projeto original. O estoque e o custo históricos não foram informados. Registre o saldo físico em **Produtos → Movimentar estoque** e ative o controle nos produtos em que desejar acompanhar esse saldo. Informe o custo para calcular a margem das compras seguintes.

Se já usa o Mercado Pandas, feche o sistema antigo, faça uma cópia de segurança e coloque seu `bd_pandas.db` dentro da pasta nova antes de abrir. A migração aproveita os registros existentes. Vendas antigas sem agrupamento são identificadas como compras de um item.

O banco fica na pasta do projeto. Há um backup automático por dia em que o app é executado e até 14 cópias diárias são mantidas. Cópias manuais também podem ser criadas pelo botão da administração ou pelo comando `python backup.py`. Para restaurar, feche o sistema, guarde o banco atual em outro local e copie o backup para `bd_pandas.db`.

## CSV

Em **Dashboards**, o administrador pode exportar o período e filtro atuais ou importar um CSV. O cabeçalho mínimo é `data;produto;quantidade`. Use o nome do catálogo e datas `AAAA-MM-DD` ou `DD/MM/AAAA`. Com ponto e vírgula como separador, a quantidade pode ser escrita como `0,350`.

Para agrupar itens, repita o mesmo `compra_id`, data, pagamento, desconto e cliente nas linhas da compra. O arquivo exportado contém o cabeçalho completo. O operador de uma importação é a conta que a confirmou. A operação inteira é desfeita se qualquer linha tiver erro ou faltar saldo.

## Testes

Com as dependências instaladas, execute na pasta do projeto:

```text
python -m unittest discover -s tests -v
```


## Dados de demonstração

O arquivo `dados_iniciais.json` contém dados fictícios para apresentação: catálogo, 300 compras e respectivos itens. Operadores e clientes são nomes fictícios; formas de pagamento foram preenchidas com uma distribuição plausível. Os custos são estimativas para demonstrar os indicadores de margem e não representam custos reais de fornecedores. O JSON só é utilizado na primeira criação do banco SQLite.

Consulte `GUIA_APRESENTACAO.md` para a divisão de explicação entre Nicolas, Wagner, Victor e MP.
