"""Funções compartilhadas pelas páginas do Streamlit."""
import logging
import sqlite3
import unicodedata
from contextlib import contextmanager

import pandas as pd
import streamlit as st

from formatos import ErroMercado, brl, data_br, moeda, qtd_br

logger = logging.getLogger(__name__)


@contextmanager
def tratar_erros():
    try:
        yield
    except ErroMercado as erro:
        st.error(str(erro))
    except (sqlite3.Error, OSError):
        logger.exception("Falha em operação do Mercado Pandas")
        st.error("Não foi possível acessar os dados. Tente novamente e confira se o banco está disponível.")


def aviso(texto):
    st.session_state.aviso_mercado = texto
    st.rerun()


def exibir_aviso():
    texto = st.session_state.pop("aviso_mercado", None)
    if texto:
        st.success(texto)


def _busca(texto):
    normalizado = unicodedata.normalize("NFKD", texto.strip().casefold())
    return "".join(letra for letra in normalizado if not unicodedata.combining(letra))


def escolher_produto(produtos, chave, *, rotulo="Produto"):
    categorias = sorted({p["categoria"] for p in produtos})
    col1, col2 = st.columns(2)
    categoria = col1.selectbox("Categoria", [None, *categorias], key=f"{chave}_categoria",
                               format_func=lambda nome: nome or "Todas")
    busca = _busca(col2.text_input("Buscar produto", key=f"{chave}_busca",
                                 placeholder="Digite o nome"))
    opcoes = {
        p["id"]: p for p in produtos
        if (categoria is None or p["categoria"] == categoria) and busca in _busca(p["nome"])
    }
    if not opcoes:
        st.info("Nenhum produto encontrado.")
        return None
    identificador = st.selectbox(rotulo, list(opcoes), key=f"{chave}_produto",
                                 format_func=lambda pid: opcoes[pid]["nome"])
    return opcoes[identificador]


def campo_quantidade(rotulo, unidade, valor=None, *, zero=False, chave=None):
    peso = unidade == "kg"
    minimo = 0.0 if zero else (0.001 if peso else 1.0)
    valor = minimo if valor is None else float(valor)
    return st.number_input(
        f"{rotulo} ({unidade})", min_value=minimo, max_value=1_000_000.0, value=valor,
        step=0.001 if peso else 1.0, format="%.3f" if peso else "%.0f", key=chave,
    )


def tabela_itens(df):
    return pd.DataFrame({
        "Compra": df["compra_id"].map(lambda valor: f"#{valor}"),
        "Data": df["data"].map(data_br),
        "Produto": df["produto"],
        "Categoria": df["categoria"],
        "Quantidade": [f"{qtd_br(qtd, un)} {un}" for qtd, un in zip(df["quantidade"], df["unidade"])],
        "Preço unitário": df["preco_unitario"].map(brl),
        "Total líquido": df["liquido_cent"].map(moeda),
        "Pagamento": df["forma_pagamento"],
    })


def figuras_periodo(df, px):
    por_dia = df.groupby("data", as_index=False)["liquido_cent"].sum()
    por_categoria = df.groupby("categoria", as_index=False)["liquido_cent"].sum()
    por_dia["faturamento"] = por_dia["liquido_cent"] / 100
    por_categoria["faturamento"] = por_categoria["liquido_cent"] / 100
    dia = px.line(por_dia, x="data", y="faturamento", markers=True, title="Faturamento por dia",
                  labels={"data": "Data", "faturamento": "Faturamento (R$)"})
    dia.update_layout(separators=",.")
    dia.update_xaxes(tickformat="%d/%m")
    dia.update_yaxes(tickprefix="R$ ", tickformat=",.2f")
    dia.update_traces(hovertemplate="%{x|%d/%m/%Y}<br>R$ %{y:,.2f}<extra></extra>")
    categoria = px.pie(por_categoria, names="categoria", values="faturamento",
                       hole=.48, title="Faturamento por categoria")
    categoria.update_layout(separators=",.")
    categoria.update_traces(hovertemplate="%{label}<br>R$ %{value:,.2f}<extra></extra>")
    return dia, categoria
