from datetime import date, timedelta

import pandas as pd
import streamlit as st

from db import limites_vendas, listar_vendas
from formatos import PAGAMENTOS, brl, data_br, moeda, qtd_br, total_item
from interface import aviso, exibir_aviso, tratar_erros
from operacoes import cancelar_compra, detalhes_compra, editar_compra

st.title("🧾 Vendas")
st.caption("Localize compras por data e produto. Abra a compra para ver todos os itens.")
exibir_aviso()

conta = st.session_state.conta
admin = conta["perfil"] == "admin"


def _mostrar_itens(compra):
    st.dataframe(pd.DataFrame([
        {
            "Produto": item["nome"],
            "Quantidade": f"{qtd_br(item['qtde'], item['unidade'])} {item['unidade']}",
            "Preço unitário": brl(item["preco"]),
            "Subtotal": moeda(total_item(item["qtde"], item["preco"])),
        }
        for item in compra["itens"]
    ]), width="stretch", hide_index=True)
    st.write(f"Desconto **{brl(compra['desconto'])}** · Total **{moeda(compra['total'])}**")


def ver(compra_id):
    with tratar_erros():
        compra = detalhes_compra(compra_id)
        st.subheader(f"Compra #{compra_id}")
        dia = data_br(date.fromisoformat(compra["data"][:10]))
        st.write(f"{dia} · {compra['forma_pagamento']} · {compra['operador']}")
        if compra["cliente"]:
            st.text(f"Cliente: {compra['cliente']}")
        if compra["cancelada_em"]:
            st.warning("Compra cancelada.")
        _mostrar_itens(compra)


def editar(compra_id, revisao):
    with tratar_erros():
        compra = detalhes_compra(compra_id)
        st.subheader(f"Editar compra #{compra_id}")
        dia_original = date.fromisoformat(compra["data"][:10])
        with st.form(f"form_editar_{compra_id}"):
            col1, col2 = st.columns(2)
            dia = col1.date_input("Data da venda", min(dia_original, date.today()), max_value=date.today(),
                                  min_value=min(dia_original, date(2000, 1, 1)), format="DD/MM/YYYY")
            opcoes = list(PAGAMENTOS)
            pagamento_antigo = compra["forma_pagamento"]
            if pagamento_antigo not in opcoes:
                pagamento_antigo = "Não informado"
            pagamento = col1.selectbox("Pagamento", opcoes, index=opcoes.index(pagamento_antigo))
            desconto = col2.number_input("Desconto (R$)", value=float(compra["desconto"]), min_value=0.0,
                                        step=0.01, format="%.2f")
            cliente = col2.text_input("Cliente (opcional)", value=compra["cliente"], max_chars=100)
            st.caption("Edite quantidade e preço. Use quantidade zero para retirar um item da compra.")
            linhas = pd.DataFrame([
                {"ID": i["id"], "Produto": i["nome"], "Un.": i["unidade"], "Quantidade": float(i["qtde"]),
                 "Preço (R$)": float(i["preco"])}
                for i in compra["itens"]
            ])
            editados = st.data_editor(
                linhas, hide_index=True, width="stretch", disabled=["ID", "Produto", "Un."],
                column_config={
                    "ID": None,
                    "Quantidade": st.column_config.NumberColumn(min_value=0, format="localized", required=True),
                    "Preço (R$)": st.column_config.NumberColumn(min_value=0, step=0.01, required=True),
                },
            )
            confirmar = st.checkbox("Confirmo as alterações desta compra.")
            enviar = st.form_submit_button("Salvar alterações", type="primary")
        if enviar:
            if not confirmar:
                st.error("Marque a confirmação antes de salvar.")
            else:
                alteracoes = {
                    int(linha["ID"]): (linha["Quantidade"], linha["Preço (R$)"])
                    for linha in editados.to_dict("records")
                }
                editar_compra(conta["id"], compra_id, revisao, dia, pagamento, desconto, cliente, alteracoes)
                st.session_state.pop("acao_vendas", None)
                aviso(f"Compra #{compra_id} atualizada.")


def excluir(compra_id, revisao):
    st.write(f"Cancelar a compra #{compra_id} e devolver o saldo baixado dos itens?")
    confirmar = st.checkbox("Confirmo o cancelamento.")
    if st.button("Confirmar cancelamento", type="primary", disabled=not confirmar):
        with tratar_erros():
            cancelar_compra(conta["id"], compra_id, revisao)
            st.session_state.pop("acao_vendas", None)
            aviso(f"Compra #{compra_id} cancelada.")


hoje = date.today()
incluir_canceladas = st.checkbox("Incluir compras canceladas")
menor, maior = limites_vendas(incluir_canceladas)
fim_padrao = min(maior or hoje, hoje)
inicio_padrao = max(min(menor or fim_padrao, fim_padrao), fim_padrao - timedelta(days=29))
minimo = min(menor or hoje, hoje)
c1, c2, c3 = st.columns([2, 2, 3])
inicio = c1.date_input("De", inicio_padrao, min_value=minimo, max_value=hoje, format="DD/MM/YYYY")
fim = c2.date_input("Até", fim_padrao, min_value=minimo, max_value=hoje, format="DD/MM/YYYY")
if inicio > fim:
    st.error("A data inicial deve ser igual ou anterior à final.")
    st.stop()

df = listar_vendas(inicio, fim, incluir_canceladas)
produtos = sorted(set(df["produto"]))
produto = c3.selectbox("Produto", [None, *produtos], format_func=lambda nome: nome or "Todos")
resumo = df if produto is None else df[df["produto"] == produto]
if resumo.empty:
    st.info("Nenhuma compra no intervalo selecionado.")
    st.stop()

ids = resumo["compra_id"].drop_duplicates().tolist()
paginas = (len(ids) + 14) // 15
st.caption(f"{len(ids)} compra(s) no período selecionado")
pagina = st.number_input("Página", min_value=1, max_value=paginas, value=1, step=1, key=f"vendas_pg_{paginas}")
visiveis = ids[(pagina - 1) * 15:pagina * 15]
for compra_id, itens in df[df["compra_id"].isin(visiveis)].groupby("compra_id", sort=False):
    compra_id = int(compra_id)
    item = itens.iloc[0]
    nomes = ", ".join(itens["produto"].drop_duplicates())
    cancelada = isinstance(item["cancelada_em"], str)
    with st.container(border=True):
        c1, c2, c3, c4 = st.columns([4, 2, 2, 3], vertical_alignment="center")
        c1.write(f"**#{compra_id} · {data_br(item['data'])}**")
        c1.text(nomes)
        c2.write(moeda(item["compra_total_cent"]))
        c2.caption(item["forma_pagamento"])
        c3.write("Cancelada" if cancelada else "Registrada")
        c3.caption(item["operador"])
        with c4:
            botoes = st.columns(3) if admin and not cancelada else (st.container(),)
            if botoes[0].button("Ver", key=f"ver_{compra_id}"):
                st.session_state.acao_vendas = (compra_id, "ver", None)
            if admin and not cancelada:
                if botoes[1].button("Editar", key=f"editar_{compra_id}"):
                    with tratar_erros():
                        st.session_state.acao_vendas = (compra_id, "editar", detalhes_compra(compra_id)["revisao"])
                if botoes[2].button("Excluir", key=f"excluir_{compra_id}", help="Cancela e mantém o registro no histórico"):
                    with tratar_erros():
                        st.session_state.acao_vendas = (compra_id, "excluir", detalhes_compra(compra_id)["revisao"])

        selecao = st.session_state.get("acao_vendas")
        if selecao and selecao[0] == compra_id:
            _, acao, revisao = selecao
            if st.button("Fechar", key=f"fechar_{compra_id}"):
                st.session_state.pop("acao_vendas")
                st.rerun()
            if acao == "ver":
                ver(compra_id)
            elif admin and not cancelada:
                if acao == "editar":
                    editar(compra_id, revisao)
                else:
                    excluir(compra_id, revisao)
