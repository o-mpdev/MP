from datetime import date, timedelta

import plotly.express as px
import streamlit as st

from db import limites_vendas, listar_vendas
from formatos import data_br, moeda, numero_br
from interface import figuras_periodo, tabela_itens

st.title("🛒 Mercado Pandas")
st.caption("Painel de gestão e análise de vendas")
st.page_link("telas/cadastrar.py", label="Nova venda", icon="➕")

hoje = date.today()
df = listar_vendas(hoje - timedelta(days=6), hoje)
if df.empty:
    _, ultima = limites_vendas()
    if ultima is None:
        st.info("Ainda não existem vendas cadastradas.")
        st.stop()
    fim = min(ultima, hoje)
    inicio = fim - timedelta(days=6)
    df = listar_vendas(inicio, fim)
    if df.empty:
        st.info("Ainda não existem vendas até a data de hoje.")
        st.stop()
    st.info(f"Sem vendas nos últimos 7 dias. Mostrando o período de {data_br(inicio)} a {data_br(fim)}.")

faturamento = df["liquido_cent"].sum()
compras = df["compra_id"].nunique()
a, b, c, d = st.columns(4)
a.metric("Faturamento", moeda(faturamento))
b.metric("Compras", numero_br(compras))
c.metric("Ticket médio", moeda(round(faturamento / compras)))
d.metric("Linhas vendidas", numero_br(len(df)))

st.subheader("Resumo do período")
col1, col2 = st.columns(2)
dia, categoria = figuras_periodo(df, px)
col1.plotly_chart(dia, width="stretch")
col2.plotly_chart(categoria, width="stretch")

st.subheader("Vendas recentes")
st.dataframe(tabela_itens(df.head(10)), width="stretch", hide_index=True)
