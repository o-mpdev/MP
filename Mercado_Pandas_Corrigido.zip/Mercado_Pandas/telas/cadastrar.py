from datetime import date
from uuid import uuid4

import streamlit as st

from db import listar_produtos
from formatos import PAGAMENTOS, brl, centavos, data_br, moeda, qtd_br, total_item, validar_quantidade
from interface import aviso, campo_quantidade, escolher_produto, exibir_aviso, tratar_erros
from operacoes import cancelar_compra, detalhes_compra, registrar_compra

st.title("➕ Nova venda")
st.caption("Monte o carrinho e registre os itens em uma só compra.")
exibir_aviso()

conta = st.session_state.conta
estado = st.session_state
carrinho = estado.setdefault("carrinho", {})
comprovante = estado.get("comprovante")
if comprovante:
    compra_id, token, revisao_original = comprovante
    with tratar_erros():
        compra = detalhes_compra(compra_id)
        if compra["cancelada_em"]:
            estado.pop("comprovante", None)
        else:
            total = moeda(compra["total"])
            st.success(f"Compra #{compra_id} registrada · {len(compra['itens'])} item(ns) · {total}.")
            with st.expander("Ver cupom da compra"):
                dia = data_br(date.fromisoformat(compra["data"][:10]))
                linhas = ["MERCADO PANDAS", f"Compra #{compra_id} · {dia}", ""]
                for item in compra["itens"]:
                    qtd = qtd_br(item["qtde"], item["unidade"])
                    liquido = moeda(total_item(item["qtde"], item["preco"]))
                    linhas.append(f"{item['nome']} · {qtd} {item['unidade']} × {brl(item['preco'])} = {liquido}")
                linhas.extend(["", f"Subtotal: {moeda(compra['subtotal'])}",
                               f"Desconto: {brl(compra['desconto'])}", f"Total: {total}",
                               f"Pagamento: {compra['forma_pagamento']}", f"Operador: {compra['operador']}"])
                if compra["cliente"]:
                    linhas.append(f"Cliente: {compra['cliente']}")
                texto = "\n".join(linhas)
                st.text(texto)
                st.download_button("Baixar cupom", texto, f"compra_{compra_id}.txt", mime="text/plain")
            if compra["revisao"] == revisao_original:
                with st.popover("Desfazer última compra"):
                    st.write("A compra será cancelada e o saldo baixado voltará ao estoque.")
                    if st.button("Confirmar que quero desfazer", key=f"desfazer_{compra_id}"):
                        with tratar_erros():
                            cancelar_compra(conta["id"], compra_id, revisao_original, operacao=token)
                            estado.pop("comprovante")
                            aviso(f"Compra #{compra_id} desfeita.")

produto = escolher_produto(listar_produtos(apenas_ativos=True), "nova_venda")
if produto:
    unidade = produto["unidade"]
    pid = produto["id"]
    quantidade = campo_quantidade("Quantidade", unidade, 0.350 if unidade == "kg" else 1,
                                 chave=f"venda_quantidade_{pid}")
    st.write(f'Preço unitário **{brl(produto["valor"])}/{unidade}**')
    st.write(f"Total do item **{moeda(total_item(quantidade, produto['valor']))}**")
    if produto["controla_estoque"]:
        st.caption(f"Saldo disponível de {qtd_br(produto['estoque'], unidade)} {unidade}")
    if st.button("Adicionar ao carrinho"):
        with tratar_erros():
            quantidade = validar_quantidade(quantidade, unidade)
            existente = carrinho.get(pid)
            if existente and (existente["preco"], existente["unidade"]) != (produto["valor"], unidade):
                st.error("O preço ou a unidade mudou. Remova o item antes de adicioná-lo novamente.")
            else:
                nova_qtde = round(quantidade + (existente["quantidade"] if existente else 0), 3)
                validar_quantidade(nova_qtde, unidade)
                if produto["controla_estoque"] and nova_qtde > produto["estoque"]:
                    st.error(f"Estoque insuficiente para {produto['nome']}.")
                else:
                    carrinho[pid] = {
                        "produto_id": pid, "nome": produto["nome"], "quantidade": nova_qtde,
                        "unidade": unidade, "preco": produto["valor"],
                    }
                    st.success(f"{produto['nome']} adicionado ao carrinho.")

st.divider()
st.subheader("Carrinho")
if not carrinho:
    st.info("O carrinho está vazio.")
    st.stop()

for pid, item in list(carrinho.items()):
    col1, col2, col3 = st.columns([5, 2, 2], vertical_alignment="center")
    col1.text(f"{item['nome']} · {qtd_br(item['quantidade'], item['unidade'])} {item['unidade']}")
    col2.write(moeda(total_item(item["quantidade"], item["preco"])))
    if col3.button("Remover", key=f"tirar_{pid}"):
        carrinho.pop(pid)
        st.rerun()

subtotal = sum(total_item(i["quantidade"], i["preco"]) for i in carrinho.values())
st.write(f"**Subtotal {moeda(subtotal)}**")
with st.expander("Dados da compra", expanded=True):
    col1, col2 = st.columns(2)
    dia = col1.date_input("Data da venda", value=date.today(), max_value=date.today(), format="DD/MM/YYYY")
    pagamento = col1.selectbox("Forma de pagamento", PAGAMENTOS)
    desconto = col2.number_input("Desconto (R$)", min_value=0.0, value=0.0, step=0.01, format="%.2f")
    cliente = col2.text_input("Cliente (opcional)", max_chars=100)
    st.caption(f"Operador: {conta['nome']}")

liquido = subtotal - centavos(desconto)
st.metric("Total da compra", moeda(max(liquido, 0)))
if liquido < 0:
    st.error("O desconto não pode superar o subtotal.")
if st.button("Registrar compra", type="primary", width="stretch", disabled=liquido < 0):
    with tratar_erros():
        token = estado.setdefault("token_compra", uuid4().hex)
        compra_id = registrar_compra(conta["id"], list(carrinho.values()), dia, pagamento, desconto, cliente, token)
        estado.comprovante = (compra_id, token, 0)
        estado.pop("token_compra", None)
        estado.carrinho = {}
        st.rerun()
