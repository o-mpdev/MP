from datetime import date, timedelta

import plotly.express as px
import streamlit as st

from csv_vendas import exportar_csv, importar_csv, ler_csv
from db import limites_vendas, listar_vendas
from formatos import data_br, moeda, numero_br
from interface import aviso, exibir_aviso, figuras_periodo, tabela_itens, tratar_erros

st.title("📊 Dashboards e relatórios")
st.caption("Indicadores, comparação por período e relatórios de vendas.")
exibir_aviso()
conta = st.session_state.conta
admin = conta["perfil"] == "admin"


def filtrar(df, categoria, produto):
    if categoria is not None:
        df = df[df["categoria"] == categoria]
    if produto is not None:
        df = df[df["produto"] == produto]
    return df


def variacao(atual, anterior):
    if anterior == 0:
        return None
    valor = (atual - anterior) / abs(anterior) * 100
    sinal = "+" if valor > 0 else ""
    return f"{sinal}{numero_br(valor, 1)}%"


def indicadores(df):
    faturamento = int(df["liquido_cent"].sum())
    compras = df["compra_id"].nunique()
    ticket = round(faturamento / compras) if compras else 0
    return faturamento, compras, len(df), ticket


hoje = date.today()
menor, ultima = limites_vendas()
inicios = {
    "Hoje": hoje,
    "7 dias": hoje - timedelta(days=6),
    "30 dias": hoje - timedelta(days=29),
    "Mês atual": hoje.replace(day=1),
}
opcoes = [*inicios, "Personalizado"]
antigas = bool(ultima and ultima < inicios["30 dias"])
atalho = st.radio("Período", opcoes, horizontal=True, index=4 if antigas else 2)
inicio, fim = inicios.get(atalho, inicios["30 dias"]), hoje
if atalho == "Personalizado":
    limite = min(menor or hoje, inicio)
    fim_padrao = ultima if antigas else hoje
    inicio_padrao = max(limite, fim_padrao - timedelta(days=29))
    c1, c2 = st.columns(2)
    inicio = c1.date_input("Data inicial", inicio_padrao, min_value=limite,
                           max_value=hoje, format="DD/MM/YYYY")
    fim = c2.date_input("Data final", fim_padrao, min_value=limite,
                         max_value=hoje, format="DD/MM/YYYY")

if inicio > fim:
    st.error("A data inicial deve ser igual ou anterior à final.")
else:
    dias = (fim - inicio).days + 1
    anterior_inicio = inicio - timedelta(days=dias)
    anterior_fim = inicio - timedelta(days=1)
    atual_bruto = listar_vendas(inicio, fim)
    anterior_bruto = listar_vendas(anterior_inicio, anterior_fim)
    cats = sorted(set(atual_bruto["categoria"]) | set(anterior_bruto["categoria"]))
    c1, c2 = st.columns(2)
    categoria = c1.selectbox("Categoria", [None, *cats], format_func=lambda nome: nome or "Todas")
    nomes = sorted(set(filtrar(atual_bruto, categoria, None)["produto"])
                   | set(filtrar(anterior_bruto, categoria, None)["produto"]))
    produto = c2.selectbox("Produto", [None, *nomes], format_func=lambda nome: nome or "Todos")

    atual = filtrar(atual_bruto, categoria, produto)
    anterior = filtrar(anterior_bruto, categoria, produto)
    dados, base = indicadores(atual), indicadores(anterior)
    st.caption(f"{data_br(inicio)} a {data_br(fim)} · Período anterior de {data_br(anterior_inicio)} a {data_br(anterior_fim)}")
    colunas = st.columns(4)
    rotulos = ["Faturamento", "Compras", "Linhas de venda", "Ticket médio"]
    formatos = [moeda, numero_br, numero_br, moeda]
    for coluna, rotulo, formato, valor, anterior_valor in zip(colunas, rotulos, formatos, dados, base):
        coluna.metric(rotulo, formato(valor), variacao(valor, anterior_valor))

    if atual.empty:
        st.info("Não há vendas no período selecionado.")
    else:
        if admin:
            conhecidos = atual[atual["custo_cent"].notna()]
            sem_custo = len(atual) - len(conhecidos)
            if not conhecidos.empty:
                receita = int(conhecidos["liquido_cent"].sum())
                custo = int(conhecidos["custo_cent"].sum())
                lucro = receita - custo
                contagem = st.columns(3)
                contagem[0].metric("Custo apurado", moeda(custo))
                contagem[1].metric("Lucro bruto apurado", moeda(lucro))
                contagem[2].metric("Margem bruta", numero_br(lucro / receita * 100, 1) + "%" if receita else "—")
            if sem_custo:
                st.caption(f"{sem_custo} item(ns) sem custo informado. Os indicadores de margem abrangem só os itens com custo registrado.")

        col1, col2 = st.columns(2)
        dia, categorias = figuras_periodo(atual, px)
        col1.plotly_chart(dia, width="stretch")
        col2.plotly_chart(categorias, width="stretch")

        col1, col2 = st.columns(2)
        with col1:
            unidade = st.selectbox("Unidade do ranking por quantidade", sorted(atual["unidade"].unique()))
            ranking = (atual[atual["unidade"] == unidade].groupby("produto", as_index=False)["quantidade"]
                       .sum().nlargest(10, "quantidade").sort_values("quantidade"))
            grafico = px.bar(ranking, x="quantidade", y="produto", orientation="h",
                             title=f"Produtos por quantidade ({unidade})",
                             labels={"quantidade": f"Quantidade ({unidade})", "produto": "Produto"})
            grafico.update_layout(separators=",.")
            st.plotly_chart(grafico, width="stretch")
        with col2:
            ranking = (atual.groupby("produto", as_index=False)["liquido_cent"].sum()
                       .nlargest(10, "liquido_cent").sort_values("liquido_cent"))
            ranking["faturamento"] = ranking["liquido_cent"] / 100
            grafico = px.bar(ranking, x="faturamento", y="produto", orientation="h",
                             title="Produtos por faturamento",
                             labels={"faturamento": "Faturamento (R$)", "produto": "Produto"})
            grafico.update_layout(separators=",.")
            grafico.update_xaxes(tickprefix="R$ ", tickformat=",.2f")
            grafico.update_traces(hovertemplate="%{y}<br>R$ %{x:,.2f}<extra></extra>")
            st.plotly_chart(grafico, width="stretch")

        st.subheader("Dados das vendas")
        tabela = tabela_itens(atual)
        if admin:
            tabela["Custo total"] = [moeda(custo) if conhecido else "—"
                                    for custo, conhecido in zip(atual["custo_cent"], atual["custo_conhecido"])]
        st.dataframe(tabela, width="stretch", hide_index=True)
        if admin:
            st.download_button("Exportar vendas em CSV", exportar_csv(atual), "relatorio_vendas.csv",
                               mime="text/csv")

if admin:
    st.divider()
    with st.expander("Importar vendas por CSV"):
        st.caption("Colunas mínimas: data, produto e quantidade. Use o nome do catálogo.")
        modelo = "data;produto;quantidade\n" + f"{hoje.isoformat()};Banana;0,350\n"
        st.download_button("Baixar modelo CSV", modelo.encode("utf-8-sig"), "modelo_vendas.csv", mime="text/csv")
        arquivo = st.file_uploader("Arquivo de vendas", type=["csv"])
        if arquivo is not None:
            with tratar_erros():
                conteudo = arquivo.getvalue()
                compras = ler_csv(conteudo)
                st.write(f"{len(compras)} compra(s) no arquivo.")
                if st.button("Confirmar importação", type="primary"):
                    total = importar_csv(conta["id"], conteudo)
                    aviso(f"{total} compra(s) importada(s).")
