from datetime import datetime

import pandas as pd
import streamlit as st

from db import backup_manual
from interface import aviso, exibir_aviso, tratar_erros
from usuarios import atualizar_usuario, criar_usuario, listar_historico, listar_usuarios

st.title("⚙️ Administração")
st.caption("Usuários, histórico de operações e backup do banco.")
exibir_aviso()

ator_id = st.session_state.conta["id"]
contas, historico, copia = st.tabs(["Usuários", "Histórico", "Backup"])
with contas:
    usuarios = listar_usuarios(ator_id)
    st.dataframe(pd.DataFrame([
        {"Usuário": u["login"], "Nome": u["nome"],
         "Perfil": "Administrador" if u["perfil"] == "admin" else "Caixa",
         "Status": "Ativo" if u["ativo"] else "Inativo"}
        for u in usuarios
    ]), hide_index=True, width="stretch")
    with st.expander("Criar usuário"):
        with st.form("novo_usuario"):
            nome = st.text_input("Nome de exibição", max_chars=80)
            login = st.text_input("Usuário", max_chars=32)
            senha = st.text_input("Senha", type="password", max_chars=128)
            perfil = st.selectbox("Perfil", ["caixa", "admin"],
                                  format_func=lambda valor: "Caixa" if valor == "caixa" else "Administrador")
            criar = st.form_submit_button("Criar usuário", type="primary")
        if criar:
            with tratar_erros():
                criar_usuario(login, nome, senha, perfil, ator_id)
                aviso("Conta criada.")
    with st.expander("Gerenciar acesso"):
        por_id = {u["id"]: u for u in usuarios}
        escolhido = st.selectbox("Conta", list(por_id), format_func=lambda uid: por_id[uid]["login"])
        with st.form(f"conta_{escolhido}"):
            ativo = st.checkbox("Conta ativa", value=bool(por_id[escolhido]["ativo"]), disabled=escolhido == ator_id)
            senha = st.text_input("Nova senha (opcional)", type="password", max_chars=128)
            salvar = st.form_submit_button("Atualizar acesso")
        if salvar:
            with tratar_erros():
                atualizar_usuario(ator_id, escolhido, ativo, senha)
                aviso("Acesso atualizado.")

with historico:
    linhas = listar_historico(ator_id)
    st.caption("Últimas 200 operações registradas.")
    if linhas:
        st.dataframe(pd.DataFrame([
            {"Data e hora": datetime.fromisoformat(x["quando"]).strftime("%d/%m/%Y %H:%M:%S"),
             "Operador": x["operador"], "Ação": x["acao"], "Referência": x["referencia"], "Detalhes": x["detalhe"]}
            for x in linhas
        ]), hide_index=True, width="stretch")
    else:
        st.info("Nenhuma operação no histórico.")

with copia:
    st.write("O sistema guarda na pasta backups uma cópia por dia de uso.")
    if st.button("Criar backup agora", type="primary"):
        with tratar_erros():
            arquivo = backup_manual()
            st.success(f"Backup salvo em backups/{arquivo.name}.")
