import pandas as pd
import streamlit as st

from db import listar_produtos
from formatos import UNIDADES, brl, numero_br, qtd_br
from interface import aviso, campo_quantidade, escolher_produto, exibir_aviso, tratar_erros
from operacoes import movimentar_estoque, salvar_produto

st.title("📦 Produtos")
st.caption("Catálogo, preços e estoque.")
exibir_aviso()

conta = st.session_state.conta
admin = conta["perfil"] == "admin"
produtos = listar_produtos()
tabela = []
for produto in produtos:
    unidade = produto["unidade"]
    linha = {
        "Produto": produto["nome"], "Categoria": produto["categoria"], "Un.": unidade,
        "Preço": brl(produto["valor"]),
        "Estoque": qtd_br(produto["estoque"], unidade) if produto["controla_estoque"] else "Sem controle",
        "Status": "Ativo" if produto["ativo"] else "Inativo",
    }
    if admin:
        valor, custo = produto["valor"], produto["custo"]
        linha["Custo"] = brl(custo) if produto["custo_conhecido"] else "Não informado"
        linha["Margem no preço"] = (
            numero_br((valor - custo) / valor * 100, 1) + "%"
            if produto["custo_conhecido"] and valor else "—"
        )
    tabela.append(linha)
if tabela:
    st.dataframe(pd.DataFrame(tabela), width="stretch", hide_index=True)

baixos = [p for p in produtos if p["ativo"] and p["controla_estoque"] and p["estoque"] <= p["estoque_minimo"]]
if baixos:
    st.warning(f"{len(baixos)} produto(s) ativo(s) no estoque mínimo ou abaixo.")
    st.dataframe(pd.DataFrame([
        {"Produto": p["nome"], "Saldo": f"{qtd_br(p['estoque'], p['unidade'])} {p['unidade']}",
         "Mínimo": f"{qtd_br(p['estoque_minimo'], p['unidade'])} {p['unidade']}"}
        for p in baixos
    ]), width="stretch", hide_index=True)

if not admin:
    st.stop()


def campos_produto(produto=None):
    dados = produto or {}
    nome = st.text_input("Nome", value=dados.get("nome", ""), max_chars=100)
    categoria = st.text_input("Categoria do produto", value=dados.get("categoria", ""), max_chars=60)
    linha = st.columns(3)
    unidade = linha[0].selectbox("Unidade de venda", UNIDADES, index=UNIDADES.index(dados.get("unidade", "un")))
    valor = linha[1].number_input("Preço de venda (R$)", min_value=0.0, value=float(dados.get("valor", 0)),
                                  step=0.01, format="%.2f")
    custo = linha[2].number_input("Custo unitário (R$)", min_value=0.0, step=0.01, format="%.2f",
                                  value=float(dados["custo"]) if dados.get("custo_conhecido") else None,
                                  placeholder="Não informado")
    st.caption("Deixe o custo em branco quando ele for desconhecido.")
    controla = st.checkbox("Controlar estoque", value=bool(dados.get("controla_estoque", True)))
    minimo = st.number_input("Estoque mínimo", min_value=0.0, step=0.001, format="%.3f",
                             value=float(dados.get("estoque_minimo", 0)))
    saldo = 0
    ativo = True
    if produto is None:
        saldo = st.number_input("Estoque inicial", min_value=0.0, step=0.001, format="%.3f")
    else:
        ativo = st.checkbox("Produto ativo", value=bool(dados["ativo"]))
    return dict(nome=nome, categoria=categoria, unidade=unidade, valor=valor, custo=custo,
                controla=controla, saldo=saldo, minimo=minimo, ativo=ativo)


st.divider()
novo, editar, estoque = st.tabs(["Novo produto", "Editar produto", "Movimentar estoque"])
with novo:
    with st.form("novo_produto"):
        dados = campos_produto()
        criar = st.form_submit_button("Cadastrar produto", type="primary")
    if criar:
        with tratar_erros():
            salvar_produto(conta["id"], **dados)
            aviso(f"Produto {dados['nome'].strip()} cadastrado.")

with editar:
    produto = escolher_produto(produtos, "editar_produto")
    if produto:
        with st.form(f"produto_{produto['id']}_{produto['revisao']}"):
            dados = campos_produto(produto)
            salvar = st.form_submit_button("Salvar produto", type="primary")
        if salvar:
            with tratar_erros():
                salvar_produto(conta["id"], produto_id=produto["id"], revisao=produto["revisao"], **dados)
                aviso(f"Produto {dados['nome'].strip()} atualizado.")

with estoque:
    produto = escolher_produto(produtos, "estoque_produto")
    if produto:
        unidade = produto["unidade"]
        st.caption(f"Saldo atual de {qtd_br(produto['estoque'], unidade)} {unidade}")
        modo = st.radio("Movimento", ["Entrada de mercadoria", "Ajustar saldo"], horizontal=True)
        entrada = modo == "Entrada de mercadoria"
        with st.form(f"estoque_{produto['id']}_{modo}"):
            quantidade = campo_quantidade("Quantidade da entrada" if entrada else "Novo saldo",
                                          unidade, None if entrada else produto["estoque"], zero=not entrada)
            motivo = st.text_input("Motivo", placeholder="Ex.: recebimento do fornecedor", max_chars=160)
            aplicar = st.form_submit_button("Registrar movimentação", type="primary")
        if aplicar:
            with tratar_erros():
                saldo = movimentar_estoque(conta["id"], produto["id"], "entrada" if entrada else "ajuste",
                                           quantidade, motivo)
                aviso(f"Estoque atualizado. Saldo de {qtd_br(saldo, unidade)} {unidade}.")
