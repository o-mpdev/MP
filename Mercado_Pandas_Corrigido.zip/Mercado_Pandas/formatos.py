"""Formatação brasileira e cálculo de preços com arredondamento em centavos."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

CENTAVO = Decimal("0.01")
UNIDADES = ("un", "kg", "dz")
PAGAMENTOS = ("Dinheiro", "Pix", "Débito", "Crédito", "Vale", "Não informado")
MAX_QUANTIDADE = Decimal("1000000")
MAX_VALOR = Decimal("100000000")


class ErroMercado(ValueError):
    """Mensagem de validação que pode aparecer na tela."""


def decimal(valor):
    try:
        numero = Decimal(str(valor))
        if numero.is_finite():
            return numero
    except (InvalidOperation, ValueError):
        pass
    raise ErroMercado("Informe um número válido.")


def validar_valor(valor, campo):
    numero = decimal(valor)
    if not 0 <= numero <= MAX_VALOR or numero != numero.quantize(CENTAVO):
        raise ErroMercado(f"{campo} deve ser positivo ou zero, com até duas casas decimais.")
    return float(numero)


def validar_quantidade(valor, unidade, *, permite_zero=False):
    numero = decimal(valor)
    casas = Decimal("0.001") if unidade == "kg" else Decimal(1)
    if not 0 <= numero <= MAX_QUANTIDADE or numero != numero.quantize(casas):
        formato = "com até três casas decimais" if unidade == "kg" else "em números inteiros"
        raise ErroMercado(f"Informe a quantidade em {unidade} {formato}.")
    if not numero and not permite_zero:
        raise ErroMercado("A quantidade deve ser maior que zero.")
    return float(numero)


def centavos(valor):
    return int((decimal(valor) * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def total_item(quantidade, preco):
    return centavos(decimal(quantidade) * decimal(preco))


def numero_br(valor, casas=0):
    return f"{valor:,.{casas}f}".translate(str.maketrans(",.", ".,"))


def brl(valor):
    return "R$ " + numero_br(valor, 2)


def moeda(valor_centavos):
    return brl(Decimal(int(valor_centavos)) / 100)


def qtd_br(valor, unidade):
    return numero_br(valor, 3 if unidade == "kg" else 0)


def data_br(valor):
    return valor.strftime("%d/%m/%Y")
