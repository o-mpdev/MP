"""Cria uma cópia manual do banco SQLite."""
import sqlite3

from db import backup_manual

if __name__ == "__main__":
    try:
        print(f"Backup criado em {backup_manual()}")
    except (sqlite3.Error, OSError) as erro:
        raise SystemExit(f"Não foi possível criar o backup: {erro}") from erro
